
"""WenDream —— 基于开源 MewCode Agent 框架深度二次开发的通用 AI 助手。

产品名 / Python 包名 / CLI 均为 ``wendream``。
``__upstream__`` 保留上游项目名称，用于 attribution，不得替换。
"""

__version__ = "0.3.0"
__upstream__ = "MewCode Agent"
__product__ = "WenDream"


