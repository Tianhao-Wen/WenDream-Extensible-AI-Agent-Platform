from __future__ import annotations

import json
from typing import Any

from wendream.conversation import Message

# 把 provider 无关的内部消息序列化成各家 API 的请求格式。
# 这一层属于「适配器」职责，对话层（ConversationManager）只管消息、不懂线上格式。


def build_anthropic_messages(messages: list[Message]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for m in messages:
        if m.tool_uses or m.thinking_blocks:
            content: list[dict[str, Any]] = []
            for tb in m.thinking_blocks:
                content.append({
                    "type": "thinking",
                    "thinking": tb.thinking,
                    "signature": tb.signature,
                })
            if m.content:
                content.append({"type": "text", "text": m.content})
            for tu in m.tool_uses:
                content.append({
                    "type": "tool_use",
                    "id": tu.tool_use_id,
                    "name": tu.tool_name,
                    "input": tu.arguments,
                })
            if not content:
                content.append({"type": "text", "text": ""})
            result.append({"role": "assistant", "content": content})
        elif m.tool_results:
            content = []
            for tr in m.tool_results:
                content.append({
                    "type": "tool_result",
                    "tool_use_id": tr.tool_use_id,
                    "content": tr.content,
                    "is_error": tr.is_error,
                })
            result.append({"role": "user", "content": content})
        elif m.images or m.documents:
            content = [
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": ib.media_type,
                        "data": ib.data,
                    },
                }
                for ib in m.images
            ]
            content.extend(
                {
                    "type": "document",
                    "source": {
                        "type": "base64",
                        "media_type": db.media_type,
                        "data": db.data,
                    },
                    **({"title": db.name} if db.name else {}),
                }
                for db in m.documents
            )
            if m.content:
                content.append({"type": "text", "text": m.content})
            result.append({"role": m.role, "content": content})
        else:
            # 合并连续的 user 纯文本消息（system-reminder 或普通 user 文本）。
            # 不合并到 tool_result 类型的 user 消息中（content 是 list）。
            if (
                m.role == "user"
                and result
                and result[-1]["role"] == "user"
                and isinstance(result[-1]["content"], str)
            ):
                result[-1]["content"] = result[-1]["content"] + "\n" + m.content
            else:
                result.append({"role": m.role, "content": m.content})
    return result


def build_openai_input(messages: list[Message]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for m in messages:
        if m.tool_uses:
            # Responses API: thinking blocks 作为 reasoning item 回传。
            for tb in (m.thinking_blocks or []):
                result.append({
                    "type": "reasoning",
                    "id": tb.signature,
                    "summary": [{"type": "summary_text", "text": tb.thinking}],
                })
            if m.content:
                result.append({"role": "assistant", "content": m.content})
            for tu in m.tool_uses:
                result.append({
                    "type": "function_call",
                    "name": tu.tool_name,
                    "call_id": tu.tool_use_id,
                    "arguments": json.dumps(tu.arguments),
                })
        elif m.tool_results:
            for tr in m.tool_results:
                result.append({
                    "type": "function_call_output",
                    "call_id": tr.tool_use_id,
                    "output": tr.content,
                })
        else:
            # 非 tool 的 assistant 消息也回传 reasoning。
            for tb in (m.thinking_blocks or []):
                result.append({
                    "type": "reasoning",
                    "id": tb.signature,
                    "summary": [{"type": "summary_text", "text": tb.thinking}],
                })
            result.append({"role": m.role, "content": m.content})
    return result


def build_chat_completion_messages(messages: list[Message]) -> list[dict[str, Any]]:
    """OpenAI Chat Completions 格式。

    - 用户消息：{"role": "user", "content": "..."}
    - 用户图片：{"role": "user", "content": [{"type": "text", "text": "..."}, {"type": "image_url", "image_url": {"url": "data:..."}}]}
    - 助手文本+工具调用：{"role": "assistant", "content": "...", "tool_calls": [...]} 
    - 工具结果：{"role": "tool", "tool_call_id": "...", "content": "..."}
    - thinking 块作为 reasoning_content 回传（DeepSeek/小米等 provider 要求）。
    """
    result: list[dict[str, Any]] = []
    for m in messages:
        reasoning = "".join(tb.thinking for tb in m.thinking_blocks) if m.thinking_blocks else ""

        if m.tool_uses:
            tool_calls = []
            for tu in m.tool_uses:
                tool_calls.append({
                    "id": tu.tool_use_id,
                    "type": "function",
                    "function": {
                        "name": tu.tool_name,
                        "arguments": json.dumps(tu.arguments),
                    },
                })
            msg: dict[str, Any] = {
                "role": "assistant",
                "content": m.content or None,
                "tool_calls": tool_calls,
            }
            if reasoning:
                msg["reasoning_content"] = reasoning
            result.append(msg)
        elif m.tool_results:
            for tr in m.tool_results:
                result.append({
                    "role": "tool",
                    "tool_call_id": tr.tool_use_id,
                    "content": tr.content,
                })
        else:
            content = m.content
            if m.images or m.documents:
                content_blocks: list[dict[str, Any]] = []
                if m.content:
                    content_blocks.append({"type": "text", "text": m.content})
                for image in m.images:
                    content_blocks.append({
                        "type": "image_url",
                        "image_url": {"url": f"data:{image.media_type};base64,{image.data}"},
                    })
                for doc in m.documents:
                    content_blocks.append({
                        "type": "file",
                        "file": {
                            "file_data": f"data:{doc.media_type};base64,{doc.data}",
                            "filename": doc.name or "document",
                        },
                    })
                content = content_blocks
            msg = {"role": m.role, "content": content}
            if reasoning:
                msg["reasoning_content"] = reasoning
            result.append(msg)
    return result


def build_messages(messages: list[Message], protocol: str = "anthropic") -> list[dict[str, Any]]:
    if protocol == "openai":
        return build_openai_input(messages)
    if protocol == "openai-compat":
        return build_chat_completion_messages(messages)
    return build_anthropic_messages(messages)
