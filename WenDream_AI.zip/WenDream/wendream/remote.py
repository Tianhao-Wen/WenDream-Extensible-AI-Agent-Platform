
"""
Remote Control 服务器：通过 WebSocket 桥接 Agent 事件和 Web UI。

使用 websockets 库提供 HTTP（静态 HTML）+ WebSocket 服务，
让用户在浏览器中与 WenDream Agent 交互。
"""

from __future__ import annotations

import asyncio
import hmac
import json
import logging
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import websockets
from websockets.asyncio.server import Server as WSServer, ServerConnection
from websockets.http11 import Request, Response

from wendream.agent import (
    Agent,
    CompactNotification,
    ErrorEvent,
    HookEvent,
    LoopComplete,
    PermissionRequest,
    PermissionResponse,
    RetryEvent,
    StreamText,
    ThinkingText,
    ToolResultEvent,
    ToolUseEvent,
    TurnComplete,
    UsageEvent,
)
from wendream import __version__
from wendream.client import create_client, resolve_context_window
from wendream.commands import CommandContext, CommandRegistry, CommandType
from wendream.commands.handlers import register_all_commands
from wendream.commands.parser import parse_command
from wendream.config import MCPServerConfig, ProviderConfig
from wendream.conversation import ConversationManager, DocumentBlock, ImageBlock, Message
from wendream.hooks import HookEngine
from wendream.mcp import MCPManager
from wendream.memory import MemoryManager, find_relevant_memories, load_instructions, render_reminder
from wendream.memory.session import TITLE_MAX_LENGTH, Session, SessionManager
from wendream.permissions import (
    DangerousCommandDetector,
    PathSandbox,
    PermissionChecker,
    PermissionMode,
    RuleEngine,
)
from wendream.skills.loader import SkillLoader
from wendream.tools import ToolRegistry, create_default_registry
from wendream.tools.load_skill import LoadSkill
from wendream.web_content import INDEX_HTML

log = logging.getLogger(__name__)

# 浏览器 WebSocket API 不支持自定义请求头，因此 token 通过 subprotocol 传递：
#   new WebSocket(url, ['wendream.v1', 'wendream-token.<token>'])
# 之所以不用 URL query，是因为 query 会进入浏览器历史与服务端访问日志。
TOKEN_SUBPROTOCOL_PREFIX = "wendream-token."
WS_SUBPROTOCOL = "wendream.v1"

# 浏览器端无人确认权限请求时，等待多久后按拒绝处理（ASK ≠ ALLOW）
PERMISSION_TIMEOUT_SECONDS = 300.0


def is_loopback_host(host: str) -> bool:
    """host 是否只能被本机访问。"""
    h = (host or "").strip().lower().strip("[]")
    if h in {"localhost", "127.0.0.1", "::1"}:
        return True
    return h.startswith("127.")


@dataclass
class RemoteSettings:
    host: str = "127.0.0.1"
    port: int = 18888
    auth_token: str | None = None
    allowed_origins: list[str] = field(default_factory=list)
    allow_unauthenticated: bool = False


class RemoteAuthError(RuntimeError):
    """Remote 启动配置不安全（非 loopback 且没有认证）。"""


def resolve_remote_settings(
    config: Any = None,
    host: str | None = None,
    port: int | None = None,
    allow_unauthenticated: bool = False,
) -> RemoteSettings:
    """合并 CLI / 配置文件 / 环境变量，得到最终的 Remote 监听设置。

    token 来源优先级：``remote.auth_token`` → 环境变量 ``WENDREAM_REMOTE_TOKEN``。
    token 本身永远不会被打印或写入日志。
    """
    remote_cfg = getattr(config, "remote", None)
    final_host = host or getattr(remote_cfg, "host", None) or "127.0.0.1"
    final_port = port or getattr(remote_cfg, "port", None) or 18888
    token = getattr(remote_cfg, "auth_token", None) or None
    if not token:
        token = os.environ.get("WENDREAM_REMOTE_TOKEN") or None
    origins = list(getattr(remote_cfg, "allowed_origins", None) or [])
    return RemoteSettings(
        host=final_host,
        port=int(final_port),
        auth_token=token,
        allowed_origins=origins,
        allow_unauthenticated=allow_unauthenticated,
    )


def provider_supports_vision(provider: ProviderConfig) -> bool:
    """返回 provider 是否应被前端视为支持图像输入。

    目前 Anthropic 与 OpenAI 系列（包括兼容协议）都可接收多模态内容，
    但旧实现只把 Anthropic 视为支持识图，导致 Qwen/DashScope 这类
    openai-compat 模型在网页端被提前拦截。对部分更老的文本模型来说它
    可能不是严格的视觉模型，但在本项目里，用户明确选中了图像输入时，
    这种“默认允许兼容协议”的行为比直接吞掉图片更符合用户预期。
    """
    if provider.protocol in {"anthropic", "openai", "openai-compat"}:
        return True
    model = provider.model.lower()
    return any(keyword in model for keyword in ("vision", "vl", "vqa", "multimodal", "qwen-vl", "llava", "gpt-4o", "gpt-4.1"))


class RemoteServer:
    """Remote Control 核心：桥接 Agent 事件和 WebSocket 客户端。"""

    def __init__(
        self,
        providers: list[ProviderConfig],
        mcp_servers: list[MCPServerConfig] | None = None,
        hook_engine: HookEngine | None = None,
        addr: str = "127.0.0.1",
        port: int = 18888,
        auth_token: str | None = None,
        allowed_origins: list[str] | None = None,
        allow_unauthenticated_remote: bool = False,
    ) -> None:
        self.providers = providers
        self._mcp_server_configs = mcp_servers or []
        self.hook_engine = hook_engine
        self.addr = addr
        self.port = port
        # token 只保存在内存，不打印、不写日志
        self.auth_token = auth_token or None
        self.allowed_origins = list(allowed_origins or [])
        self.allow_unauthenticated_remote = bool(allow_unauthenticated_remote)

        # WebSocket 连接池（支持多客户端广播）
        self._connections: set[ServerConnection] = set()

        # Agent 相关状态
        self.agent: Agent | None = None
        self.conversation: ConversationManager | None = None
        self.registry: ToolRegistry | None = None
        self.session_id: str = ""
        self._streaming = False
        self._cancel_event: asyncio.Event | None = None
        # 当前生效的 provider（网页端可切换，默认取列表第一个）
        self._active_provider: ProviderConfig = providers[0]

        # 最后一轮对话的版本历史（仅内存，供网页端 ‹ N/M › 来回切换编辑/重新生成的
        # 不同版本；刷新页面/重启服务不保留，切会话/切 provider/开新对话时清空）。
        self._turn_versions: list[list[Message]] = []
        self._turn_versions_idx: int = 0

        # 权限请求的 pending 队列：id -> Future
        self._pending_perms: dict[str, asyncio.Future[PermissionResponse]] = {}

        # 命令注册表
        self.command_registry = CommandRegistry()
        register_all_commands(self.command_registry)

        # MCP 相关
        self.mcp_manager: MCPManager | None = None
        self._mcp_instructions: str = ""

        # Skill 加载器
        self.skill_loader: SkillLoader | None = None

        # Memory / Session
        self.memory_manager: MemoryManager | None = None
        self.session_manager: SessionManager | None = None
        self.session: Session | None = None
        # 已落盘到当前 session 文件的消息对象 id() 集合，用于增量持久化。
        # 必须跟随 self.session 的生命周期重置（新建/切换会话时清空或
        # 预置为已加载的消息），否则每一轮新消息都会把此前的历史重新写入
        # 磁盘一遍，导致同一段对话在 session 文件里成倍重复。
        self._persisted_ids: set[int] = set()

    # ------------------------------------------------------------------
    # 启动入口
    # ------------------------------------------------------------------

    async def run(self) -> None:
        """启动 HTTP + WebSocket 服务器。"""
        # 启动前先校验绑定安全性：非 loopback 且无 token 直接拒绝启动。
        self._validate_binding()

        # 初始化 Agent
        self._init_agent()

        # 初始化 MCP（如果有配置）
        await self._init_mcp()

        print(f"\n  WenDream AI智能体: http://{self._display_host()}:{self.port}\n")

        # websockets 的 serve 支持 process_request 回调来处理普通 HTTP
        async with websockets.serve(
            self._ws_handler,
            self.addr,
            self.port,
            process_request=self._process_http_request,
            max_size=32 * 1024 * 1024,  # 32MB 消息上限（对齐 Anthropic 单次请求量级，容纳 base64 图片）
        ):
            # 服务器启动后永久阻塞
            await asyncio.Future()

    # ------------------------------------------------------------------
    # 绑定 / 认证 / Origin 校验
    # ------------------------------------------------------------------

    def _validate_binding(self) -> None:
        """非 loopback 绑定必须带 token，否则拒绝启动。"""
        if is_loopback_host(self.addr):
            return
        if self.auth_token:
            print(
                "WARNING: Remote server is listening on a non-loopback interface "
                f"({self.addr}). Anyone who can reach this port may attempt to connect; "
                "access is gated by the configured token.",
                file=__import__("sys").stderr,
            )
            return
        if self.allow_unauthenticated_remote:
            print(
                "WARNING: Remote server is listening on a non-loopback interface "
                f"({self.addr}) WITHOUT authentication. This is dangerous; "
                "only use it on a trusted network.",
                file=__import__("sys").stderr,
            )
            return
        raise RemoteAuthError(
            f"Refusing to bind remote server to non-loopback address {self.addr!r} "
            "without authentication. Set WENDREAM_REMOTE_TOKEN (or remote.auth_token), "
            "or pass --allow-unauthenticated-remote if you really want an open endpoint."
        )

    def _display_host(self) -> str:
        return "127.0.0.1" if is_loopback_host(self.addr) else self.addr

    def _origin_allowed(self, origin: str) -> bool:
        allowed = {
            f"http://127.0.0.1:{self.port}",
            f"http://localhost:{self.port}",
            f"http://[::1]:{self.port}",
        }
        allowed.update(self.allowed_origins)
        normalized = {item.rstrip("/").lower() for item in allowed}
        return origin.rstrip("/").lower() in normalized

    def _token_from_request(self, request: Request) -> str | None:
        header = request.headers.get("Authorization")
        if header and header.lower().startswith("bearer "):
            return header[7:].strip()
        proto = request.headers.get("Sec-WebSocket-Protocol") or ""
        for item in proto.split(","):
            item = item.strip()
            if item.startswith(TOKEN_SUBPROTOCOL_PREFIX):
                return item[len(TOKEN_SUBPROTOCOL_PREFIX):]
        return None

    def authorize_request(self, request: Request) -> tuple[bool, str]:
        """返回 (是否放行, 拒绝原因)。供握手阶段调用，也便于测试。"""
        origin = request.headers.get("Origin")
        if origin and not self._origin_allowed(origin):
            return False, "origin"
        if self.auth_token:
            supplied = self._token_from_request(request) or ""
            if not hmac.compare_digest(supplied, self.auth_token):
                return False, "token"
        return True, ""

    # ------------------------------------------------------------------
    # HTTP 请求处理（为 / 路径提供前端 HTML）
    # ------------------------------------------------------------------

    def _process_http_request(
        self, connection: ServerConnection, request: Request
    ) -> Response | None:
        """拦截 HTTP 请求，对 / 路径返回 HTML 页面。
        返回 None 表示继续走 WebSocket 升级流程。
        """
        if request.path == "/":
            page = INDEX_HTML.replace("__WENDREAM_VERSION__", __version__)
            return Response(
                200,
                "OK",
                websockets.Headers({"Content-Type": "text/html; charset=utf-8"}),
                page.encode("utf-8"),
            )
        if request.path != "/ws":
            return Response(404, "Not Found", websockets.Headers(), b"404 Not Found")
        # /ws 路径 → 先做 Origin / token 校验，通过后才继续 WebSocket 升级
        ok, reason = self.authorize_request(request)
        if not ok:
            if reason == "token":
                return Response(
                    401,
                    "Unauthorized",
                    websockets.Headers({"Content-Type": "text/plain; charset=utf-8"}),
                    b"Unauthorized",
                )
            return Response(
                403,
                "Forbidden",
                websockets.Headers({"Content-Type": "text/plain; charset=utf-8"}),
                b"Forbidden origin",
            )
        return None

    # ------------------------------------------------------------------
    # WebSocket 连接处理
    # ------------------------------------------------------------------

    async def _ws_handler(self, websocket: ServerConnection) -> None:
        """处理单个 WebSocket 连接的全生命周期。"""
        self._connections.add(websocket)
        try:
            # 连接建立时推送会话信息
            await self._broadcast({
                "type": "connected",
                "data": {
                    "session": self.session_id,
                    "cwd": os.getcwd(),
                    "visionEnabled": provider_supports_vision(self._active_provider),
                    "activeProvider": self._active_provider.name,
                },
            })

            # 推送命令列表
            await self._broadcast({
                "type": "commands",
                "data": self._build_command_list(),
            })

            # 推送可切换的 provider 列表
            await self._broadcast({
                "type": "providers",
                "data": {
                    "providers": [
                        {"name": p.name, "protocol": p.protocol, "model": p.model}
                        for p in self.providers
                    ],
                    "active": self._active_provider.name,
                },
            })

            # 推送历史会话列表（侧边栏）
            await self._broadcast({
                "type": "session_list",
                "data": {"sessions": self._build_session_list()},
            })

            # 消息循环
            async for raw in websocket:
                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError:
                    continue

                msg_type = msg.get("type", "")
                data = msg.get("data", {})

                if msg_type == "user_message":
                    content = data.get("content", "").strip()
                    images_raw = data.get("images", []) or []
                    image_blocks = [
                        ImageBlock(media_type=i.get("media_type", ""), data=i.get("data", ""))
                        for i in images_raw
                        if isinstance(i, dict) and i.get("media_type") and i.get("data")
                    ]
                    documents_raw = data.get("documents", []) or []
                    document_blocks = [
                        DocumentBlock(
                            media_type=d.get("media_type", ""),
                            data=d.get("data", ""),
                            name=d.get("name", ""),
                        )
                        for d in documents_raw
                        if isinstance(d, dict) and d.get("media_type") and d.get("data")
                    ]
                    if content or image_blocks or document_blocks:
                        # 在后台任务中处理，不阻塞 WebSocket 读循环
                        asyncio.create_task(
                            self._handle_user_message(content, image_blocks, document_blocks)
                        )

                elif msg_type == "permission_response":
                    self._handle_permission_response(data)

                elif msg_type == "cancel":
                    if self._cancel_event is not None:
                        self._cancel_event.set()

                elif msg_type == "ping":
                    # 应用层保活
                    await self._broadcast({"type": "pong", "data": None})

                elif msg_type == "new_session":
                    asyncio.create_task(self._handle_new_session())

                elif msg_type == "load_session":
                    session_id = data.get("id", "")
                    if session_id:
                        asyncio.create_task(self._handle_load_session(session_id))

                elif msg_type == "delete_session":
                    session_id = data.get("id", "")
                    if session_id:
                        asyncio.create_task(self._handle_delete_session(session_id))

                elif msg_type == "rename_session":
                    session_id = data.get("id", "")
                    title = data.get("title", "").strip()
                    if session_id and title:
                        asyncio.create_task(self._handle_rename_session(session_id, title))

                elif msg_type == "switch_provider":
                    provider_name = data.get("name", "")
                    if provider_name:
                        asyncio.create_task(self._handle_switch_provider(provider_name))

                elif msg_type == "regenerate":
                    asyncio.create_task(self._handle_regenerate())

                elif msg_type == "edit_message":
                    new_content = data.get("content", "").strip()
                    if new_content:
                        asyncio.create_task(self._handle_edit_message(new_content))

                elif msg_type == "switch_turn_version":
                    version_index = data.get("index")
                    if isinstance(version_index, int):
                        asyncio.create_task(self._handle_switch_turn_version(version_index))

        except websockets.ConnectionClosed:
            pass
        finally:
            self._connections.discard(websocket)

    # ------------------------------------------------------------------
    # Agent 初始化（复刻 TUI 的 _select_provider 流程）
    # ------------------------------------------------------------------

    def _init_agent(self) -> None:
        """初始化 Agent 及相关子系统。"""
        provider = self._active_provider
        work_dir = str(Path(os.getcwd()).resolve())
        home = Path.home()

        # 权限系统
        checker = PermissionChecker(
            detector=DangerousCommandDetector(),
            sandbox=PathSandbox(work_dir),
            rule_engine=RuleEngine(
                user_rules_path=home / ".wendream" / "permissions.yaml",
                project_rules_path=Path(work_dir) / ".wendream" / "permissions.yaml",
                local_rules_path=Path(work_dir) / ".wendream" / "permissions.local.yaml",
            ),
            mode=PermissionMode.DEFAULT,
        )

        # 加载自定义指令和记忆
        instructions = load_instructions(work_dir)
        self.memory_manager = MemoryManager(work_dir)
        self.session_manager = SessionManager(work_dir)
        self.session = self.session_manager.create()
        self.session_id = self.session.session_id
        self._persisted_ids = set()

        # 创建 LLM 客户端
        client = create_client(provider)

        # 工具注册表（workspace 根必须与 Agent / PathSandbox 一致）
        self.registry = create_default_registry(work_dir=work_dir)

        # Skill 加载
        self.skill_loader = SkillLoader(work_dir)
        self.skill_loader.load_all()
        load_skill_tool = LoadSkill()
        self.registry.register(load_skill_tool)

        # 创建 Agent
        self.agent = Agent(
            client=client,
            registry=self.registry,
            protocol=provider.protocol,
            work_dir=work_dir,
            permission_checker=checker,
            context_window=provider.get_context_window(),
            instructions_content=instructions,
            memory_manager=self.memory_manager,
            hook_engine=self.hook_engine,
        )
        self.agent.session_id = self.session_id

        # 连接 Skill 到 Agent
        load_skill_tool.set_loader(self.skill_loader)
        load_skill_tool.set_agent(self.agent)

        catalog = self.skill_loader.get_catalog()
        if catalog:
            lines = ["You can use the following Skills:", ""]
            for name, desc in catalog:
                lines.append(f"- {name}: {desc}")
            lines.append("")
            lines.append("If the user's request matches a Skill, call LoadSkill to activate it.")
            self.agent.set_skill_catalog("\n".join(lines))

        # 初始化对话管理器
        self.conversation = ConversationManager()

        log.info("Agent initialized: session=%s, model=%s", self.session_id, provider.model)

    # ------------------------------------------------------------------
    # MCP 初始化
    # ------------------------------------------------------------------

    async def _init_mcp(self) -> None:
        """连接所有配置的 MCP 服务器，注册工具。"""
        if not self._mcp_server_configs or self.registry is None:
            return

        manager = MCPManager()
        manager.load_configs(self._mcp_server_configs)
        connect_result = await manager.register_all_tools(self.registry)
        self.mcp_manager = manager

        for err in connect_result.errors:
            log.warning("MCP error: %s", err)

        # 构建 MCP 指令（首次发送消息时注入 conversation）
        if connect_result.servers:
            parts = []
            for srv_info in connect_result.servers:
                section = f"## {srv_info.name}\n"
                if srv_info.instructions:
                    section += srv_info.instructions
                else:
                    tool_names = [
                        t.name for t in self.registry.list_tools()
                        if t.name.startswith(f"mcp__{srv_info.name}__")
                    ]
                    if tool_names:
                        section += "Available tools: " + ", ".join(tool_names)
                parts.append(section)
            self._mcp_instructions = (
                "# MCP Server Instructions\n\n"
                "The following MCP servers have provided instructions "
                "for how to use their tools and resources:\n\n"
                + "\n\n".join(parts)
            )

    # ------------------------------------------------------------------
    # 记忆精选召回（对齐 TUI 的 _prefetch_relevant_memories）
    # ------------------------------------------------------------------

    async def _prefetch_relevant_memories(self, query: str) -> str:
        """用一次独立的 side-query（8s 超时）挑出最多 5 条与当前消息最相关的
        记忆文件，返回渲染好的完整正文 system-reminder 文本；失败/超时返回 ""。

        用独立的 LLM client，使 selector 的 system prompt 不受主对话
        system prompt 影响。best-effort：任何失败都不应阻塞主对话。
        """
        if self.memory_manager is None or not self.providers:
            return ""

        provider = self._active_provider
        user_dir = self.memory_manager.user_mem_dir
        project_dir = self.memory_manager.project_mem_dir

        async def selector(system_prompt: str, user_message: str) -> str:
            from wendream.tools.base import StreamEnd, TextDelta

            side_client = create_client(provider)
            mini_conv = ConversationManager()
            mini_conv.history = [Message(role="user", content=user_message)]
            collected = ""
            async for event in side_client.stream(mini_conv, system=system_prompt):
                if isinstance(event, TextDelta):
                    collected += event.text
                elif isinstance(event, StreamEnd):
                    pass
            return collected

        try:
            results = await asyncio.wait_for(
                find_relevant_memories(
                    query=query,
                    user_mem_dir=user_dir,
                    project_mem_dir=project_dir,
                    recent_tools=None,
                    already_surfaced=None,
                    selector=selector,
                ),
                timeout=8.0,
            )
            return render_reminder(results)
        except (asyncio.TimeoutError, Exception):
            return ""

    # ------------------------------------------------------------------
    # 用户消息处理
    # ------------------------------------------------------------------

    async def _handle_user_message(
        self,
        content: str,
        images: list[ImageBlock] | None = None,
        documents: list[DocumentBlock] | None = None,
        _same_turn: bool = False,
    ) -> None:
        """处理来自 Web UI 的用户消息或斜杠命令。

        _same_turn=True 表示这次调用来自「重新生成/编辑」——即在同一个提问位置
        上再来一版，而不是一条全新的消息。此时不清空该位置已经积累的版本历史。
        """
        if self._streaming:
            return

        # 斜杠命令
        if content.startswith("/"):
            await self._handle_slash_command(content)
            return

        # 普通消息 → 发给 Agent
        self._streaming = True
        assert self.conversation is not None
        assert self.agent is not None

        if not _same_turn:
            # 一条全新的消息：之前追踪的版本历史（如果有）已经跟不上了，清空。
            self._turn_versions = []
            self._turn_versions_idx = 0

        # 在主对话开始前先起一个后台任务，精选最相关的记忆（不阻塞主流程）
        prefetch_task = asyncio.create_task(self._prefetch_relevant_memories(content))

        self.conversation.add_user_message(content, images=images, documents=documents)
        user_msg = self.conversation.history[-1]
        if self.session is not None:
            self.session.append(user_msg)
            self._persisted_ids.add(id(user_msg))

        if _same_turn:
            # 编辑/重新生成时这条消息是服务端直接重发的，不是用户在输入框里敲的，
            # 前端没有机会提前本地渲染——这里补一条 replay_user 广播出去。
            await self._broadcast({
                "type": "replay_user",
                "data": {
                    "content": user_msg.content,
                    "images": [
                        {"media_type": ib.media_type, "data": ib.data}
                        for ib in user_msg.images
                    ],
                    "documents": [
                        {"media_type": db.media_type, "data": db.data, "name": db.name}
                        for db in user_msg.documents
                    ],
                },
            })

        def flush_new_messages() -> None:
            """把 conversation.history 中尚未落盘的消息追加写入 session。

            用对象身份（而非下标游标）跟踪已持久化的消息，且该集合是
            RemoteServer 实例级别的状态（跟随 self.session 的生命周期），而
            不是每次调用重新创建：agent.run() 可能会在历史记录靠前的位置插入
            env/长期记忆注入的 system-reminder 消息，这会把原本在游标之前的
            用户消息「挤」到游标之后，导致基于下标切片的游标失效；而如果
            用一个每次调用都重新清空的局部集合来做身份追踪，则会在同一个
            会话的第二轮及之后每次把此前已经写过的历史重新写一遍，导致
            session 文件里的对话成倍重复。
            """
            if self.session is None:
                return
            for msg in self.conversation.history:
                if id(msg) not in self._persisted_ids:
                    self.session.append(msg)
                    self._persisted_ids.add(id(msg))

        # 首次注入 MCP 指令
        if self._mcp_instructions:
            self.conversation.add_system_reminder(self._mcp_instructions)
            self._mcp_instructions = ""

        # 把精选记忆的 prefetch 任务交给 agent：工具执行完毕后，agent 会在
        # 任务就绪时把结果作为 system-reminder 注入本轮对话（agent.py 中
        # memory_recall_task 消费逻辑），不阻塞主流程。
        self.agent.memory_recall_task = prefetch_task
        self.agent._memory_recall_consumed = False

        # 创建取消事件
        self._cancel_event = asyncio.Event()
        start_time = time.monotonic()
        stream_buf = ""

        try:
            async for event in self.agent.run(self.conversation):
                # 检查取消信号
                if self._cancel_event.is_set():
                    break

                if isinstance(event, StreamText):
                    stream_buf += event.text
                    await self._broadcast({
                        "type": "stream_text",
                        "data": {"text": event.text},
                    })

                elif isinstance(event, ThinkingText):
                    await self._broadcast({
                        "type": "thinking_text",
                        "data": {"text": event.text},
                    })

                elif isinstance(event, ToolUseEvent):
                    await self._broadcast({
                        "type": "tool_use",
                        "data": {
                            "toolId": event.tool_id,
                            "toolName": event.tool_name,
                            "args": event.arguments,
                        },
                    })

                elif isinstance(event, ToolResultEvent):
                    # 如果之前有累积的流式文本，先结束它
                    if stream_buf:
                        await self._broadcast({
                            "type": "stream_end",
                            "data": {"text": stream_buf},
                        })
                        stream_buf = ""
                    await self._broadcast({
                        "type": "tool_result",
                        "data": {
                            "toolId": event.tool_id,
                            "toolName": event.tool_name,
                            "output": event.output,
                            "isError": event.is_error,
                            "elapsed": event.elapsed,
                        },
                    })

                elif isinstance(event, PermissionRequest):
                    # 生成唯一 ID，等待 Web 端回复；无人回复则超时后默认拒绝（ASK ≠ ALLOW）。
                    perm_id = f"perm_{time.time_ns()}"
                    self._pending_perms[perm_id] = event.future
                    asyncio.create_task(self._expire_permission(perm_id, event.future))
                    await self._broadcast({
                        "type": "permission_request",
                        "data": {
                            "id": perm_id,
                            "toolName": event.tool_name,
                            "description": event.description,
                        },
                    })

                elif isinstance(event, TurnComplete):
                    if stream_buf:
                        await self._broadcast({
                            "type": "stream_end",
                            "data": {"text": stream_buf},
                        })
                        stream_buf = ""
                    flush_new_messages()
                    await self._broadcast({
                        "type": "turn_complete",
                        "data": {"turn": event.turn},
                    })

                elif isinstance(event, LoopComplete):
                    if stream_buf:
                        await self._broadcast({
                            "type": "stream_end",
                            "data": {"text": stream_buf},
                        })
                        stream_buf = ""
                    flush_new_messages()
                    if self.session is not None:
                        self.session.meta.total_tokens = (
                            self.agent.total_input_tokens + self.agent.total_output_tokens
                        )
                    elapsed = time.monotonic() - start_time
                    await self._broadcast({
                        "type": "loop_complete",
                        "data": {
                            "totalTurns": event.total_turns,
                            "elapsed": elapsed,
                        },
                    })
                    await self._broadcast_session_list()

                elif isinstance(event, UsageEvent):
                    await self._broadcast({
                        "type": "usage",
                        "data": {
                            "inputTokens": event.input_tokens,
                            "outputTokens": event.output_tokens,
                        },
                    })

                elif isinstance(event, ErrorEvent):
                    await self._broadcast({
                        "type": "error",
                        "data": {"message": event.message},
                    })

                elif isinstance(event, CompactNotification):
                    await self._broadcast({
                        "type": "compact",
                        "data": {"message": event.message},
                    })

                elif isinstance(event, RetryEvent):
                    await self._broadcast({
                        "type": "retry",
                        "data": {
                            "reason": event.reason,
                            "waitMs": int(event.wait * 1000),
                        },
                    })

                elif isinstance(event, HookEvent):
                    status = "ok" if event.success else "error"
                    await self._broadcast({
                        "type": "system",
                        "data": {
                            "message": f"Hook [{event.hook_id}] {status}: {event.output}"
                        },
                    })

        except asyncio.CancelledError:
            await self._broadcast({
                "type": "error",
                "data": {"message": "Operation cancelled"},
            })
        except Exception as exc:
            log.exception("Agent run error")
            await self._broadcast({
                "type": "error",
                "data": {"message": str(exc)},
            })
        finally:
            self._streaming = False
            self._cancel_event = None
            # 把这一轮跑完之后的结果记一个版本快照（仅内存），供 ‹ N/M › 导航用。
            # 用身份而非下标定位 user_msg：agent.run() 可能在它前面插入了
            # env/长期记忆的 system-reminder，把它的下标往后挤。
            pos = next(
                (i for i, m in enumerate(self.conversation.history) if m is user_msg),
                None,
            )
            if pos is not None:
                self._turn_versions.append(list(self.conversation.history[pos:]))
                self._turn_versions_idx = len(self._turn_versions) - 1
                await self._broadcast_turn_version()

    # ------------------------------------------------------------------
    # 斜杠命令处理
    # ------------------------------------------------------------------

    async def _handle_slash_command(self, input_text: str) -> None:
        """分发斜杠命令。"""
        name, args, is_command = parse_command(input_text)
        if not is_command or not name:
            return

        cmd = self.command_registry.find(name)
        if cmd is None:
            await self._broadcast({
                "type": "error",
                "data": {"message": f"Unknown command: /{name} — type /help to see available commands"},
            })
            await self._broadcast({"type": "command_done", "data": None})
            return

        # 需要参数但没给
        if not args and cmd.arg_prompt:
            await self._broadcast({
                "type": "system",
                "data": {"message": cmd.arg_prompt},
            })
            await self._broadcast({"type": "command_done", "data": None})
            return

        if cmd.type == CommandType.LOCAL:
            # 本地命令直接执行
            ctx = self._build_command_context(args)
            try:
                await cmd.handler(ctx)
            except Exception as exc:
                await self._broadcast({
                    "type": "error",
                    "data": {"message": f"Command error: {exc}"},
                })
            await self._broadcast({"type": "command_done", "data": None})

        elif cmd.type == CommandType.LOCAL_UI:
            # UI 命令需要特殊处理
            if name == "clear":
                self.conversation = ConversationManager()
                self._persisted_ids = set()
                if self.agent is not None:
                    self.agent.clear_active_skills()
                await self._broadcast({"type": "clear", "data": None})

            elif name == "compact":
                await self._handle_compact()
                return

            else:
                await self._broadcast({
                    "type": "system",
                    "data": {"message": f"/{name} is not fully supported in remote mode."},
                })

            await self._broadcast({"type": "command_done", "data": None})

        elif cmd.type == CommandType.PROMPT:
            # Prompt 类命令：handler 返回 prompt 文本，注入给 agent
            ctx = self._build_command_context(args)
            try:
                await cmd.handler(ctx)
            except Exception as exc:
                await self._broadcast({
                    "type": "error",
                    "data": {"message": f"Command error: {exc}"},
                })
                await self._broadcast({"type": "command_done", "data": None})

    def _build_command_context(self, args: str) -> CommandContext:
        """构建命令上下文。"""
        return CommandContext(
            args=args,
            agent=self.agent,
            conversation=self.conversation,
            session=self.session,
            session_manager=self.session_manager,
            memory_manager=self.memory_manager,
            ui=self,  # type: ignore[arg-type]
            config={
                "registry": self.command_registry,
            },
        )

    # ------------------------------------------------------------------
    # 会话管理（新建 / 加载 / 删除，供 Web 侧边栏使用）
    # ------------------------------------------------------------------

    def _build_session_list(self) -> list[dict[str, Any]]:
        """构建会话列表，推送给前端渲染历史侧边栏。"""
        if self.session_manager is None:
            return []
        result: list[dict[str, Any]] = []
        for meta in self.session_manager.list():
            result.append({
                "id": meta.id,
                "title": meta.title or meta.summary or "",
                "messageCount": meta.message_count,
                "createdAt": meta.created_at.isoformat(),
                "lastActive": meta.last_active.isoformat(),
            })
        return result

    async def _broadcast_session_list(self) -> None:
        await self._broadcast({
            "type": "session_list",
            "data": {"sessions": self._build_session_list()},
        })

    async def _broadcast_turn_version(self) -> None:
        await self._broadcast({
            "type": "turn_version",
            "data": {"index": self._turn_versions_idx, "total": len(self._turn_versions)},
        })

    async def _handle_new_session(self) -> None:
        """开始一个全新的对话（侧边栏「新建对话」）。"""
        if self._streaming:
            await self._broadcast({
                "type": "error",
                "data": {"message": "Please wait for the current response to finish."},
            })
            return
        assert self.session_manager is not None
        assert self.agent is not None

        if self.session is not None:
            self.session.close()

        self.session = self.session_manager.create()
        self.session_id = self.session.session_id
        self.agent.session_id = self.session_id
        self.agent._loop_count = 0
        self.agent.clear_active_skills()
        self.conversation = ConversationManager()
        self._persisted_ids = set()
        self._turn_versions = []
        self._turn_versions_idx = 0

        await self._broadcast({"type": "clear", "data": None})
        await self._broadcast({
            "type": "session_switched",
            "data": {"id": self.session_id, "cwd": os.getcwd(), "title": ""},
        })
        await self._broadcast_turn_version()
        await self._broadcast_session_list()

    async def _handle_switch_provider(self, provider_name: str) -> None:
        """切换网页端使用的模型/provider。

        协议不同的 provider 之间图片/文档内容块无法互相翻译（比如 Anthropic
        专属的 image/document block 拿去发给 openai-compat 会被直接忽略），
        所以切换 provider 等同于开一个新对话——旧对话历史保留在磁盘上，随时
        可以从侧边栏切回去，只是不会带着切换前的上下文继续聊。
        """
        if self._streaming:
            await self._broadcast({
                "type": "error",
                "data": {"message": "Please wait for the current response to finish."},
            })
            return

        target = next((p for p in self.providers if p.name == provider_name), None)
        if target is None or target.name == self._active_provider.name:
            return

        assert self.session_manager is not None
        assert self.agent is not None

        self._active_provider = target
        self.agent.client = create_client(target)
        self.agent.protocol = target.protocol
        self.agent.context_window = target.get_context_window()

        if self.session is not None:
            self.session.close()
        self.session = self.session_manager.create()
        self.session_id = self.session.session_id
        self.agent.session_id = self.session_id
        self.agent._loop_count = 0
        self.agent.clear_active_skills()
        self.conversation = ConversationManager()
        self._persisted_ids = set()
        self._turn_versions = []
        self._turn_versions_idx = 0

        await self._broadcast({"type": "clear", "data": None})
        await self._broadcast({
            "type": "session_switched",
            "data": {
                "id": self.session_id,
                "cwd": os.getcwd(),
                "title": "",
                "visionEnabled": provider_supports_vision(target),
                "activeProvider": target.name,
            },
        })
        await self._broadcast_turn_version()
        await self._broadcast_session_list()

    async def _handle_load_session(self, session_id: str) -> None:
        """加载并重放一个历史会话。"""
        if self._streaming:
            await self._broadcast({
                "type": "error",
                "data": {"message": "Please wait for the current response to finish."},
            })
            return
        if session_id == self.session_id:
            return
        assert self.session_manager is not None
        assert self.agent is not None

        result = self.session_manager.resume(session_id)
        if result is None:
            await self._broadcast({
                "type": "error",
                "data": {"message": f"Session not found: {session_id}"},
            })
            return

        if self.session is not None:
            self.session.close()

        self.session = result.session
        self.session_id = session_id
        self.agent.session_id = session_id
        self.agent._loop_count = 0
        self.agent.clear_active_skills()

        conv = ConversationManager()
        for msg in result.messages:
            conv.history.append(msg)
        self.conversation = conv
        # 刚从磁盘加载的消息本来就已经落盘了，标记为已持久化，
        # 避免下一轮 flush_new_messages() 把它们当作新消息重复写入。
        self._persisted_ids = {id(m) for m in conv.history}
        self._turn_versions = []
        self._turn_versions_idx = 0

        await self._broadcast({"type": "clear", "data": None})
        await self._broadcast({
            "type": "session_switched",
            "data": {
                "id": self.session_id,
                "cwd": os.getcwd(),
                "title": result.session.meta.title,
            },
        })

        await self._replay_messages(result.messages)
        await self._broadcast_turn_version()

    async def _replay_messages(self, messages: list[Message]) -> None:
        """把一段历史消息重放到前端：跳过系统提醒注入和纯工具结果消息，
        助手消息若带工具调用则附上简短的工具使用提示。
        """
        for message in messages:
            if message.tool_results:
                continue
            if message.role == "user":
                if (
                    (not message.content and not message.images and not message.documents)
                    or message.content.startswith("<system-reminder>")
                    or message.content.startswith("Current working directory:")
                ):
                    continue
                await self._broadcast({
                    "type": "replay_user",
                    "data": {
                        "content": message.content,
                        "images": [
                            {"media_type": ib.media_type, "data": ib.data}
                            for ib in message.images
                        ],
                        "documents": [
                            {"media_type": db.media_type, "data": db.data, "name": db.name}
                            for db in message.documents
                        ],
                    },
                })
            elif message.role == "assistant":
                content = message.content
                if message.tool_uses:
                    tool_names = ", ".join(f"`{tu.tool_name}`" for tu in message.tool_uses)
                    content = (content or "") + f"\n\n> 🔧 used {tool_names}"
                if content:
                    await self._broadcast({
                        "type": "replay_assistant",
                        "data": {"content": content},
                    })

    def _find_last_human_message_index(self) -> int | None:
        """从后往前找最后一条「人类真正打字发送的」user 消息的下标。

        conversation.history 里 role == "user" 的消息还包括工具结果回填
        （tool_results 非空）和系统提醒注入，这些不是编辑/重新生成的对象。
        """
        assert self.conversation is not None
        for i in range(len(self.conversation.history) - 1, -1, -1):
            m = self.conversation.history[i]
            if m.role == "user" and not m.tool_results:
                return i
        return None

    async def _handle_regenerate(self) -> None:
        """重新生成最后一条用户消息对应的回复：丢弃它之后的所有内容，原样重发。"""
        if self._streaming:
            return
        assert self.conversation is not None
        assert self.session is not None

        idx = self._find_last_human_message_index()
        if idx is None:
            return
        last_user = self.conversation.history[idx]
        self.conversation.history = self.conversation.history[:idx]
        self._persisted_ids = {id(m) for m in self.conversation.history}
        self.session.rewrite(self.conversation.history)
        # 从当前正看着的那一版分支出去：如果之前后退看过旧版本，
        # 比它更新的那些版本在这里就作废了。
        if self._turn_versions:
            self._turn_versions = self._turn_versions[: self._turn_versions_idx + 1]

        await self._broadcast({"type": "clear", "data": None})
        await self._replay_messages(self.conversation.history)
        await self._handle_user_message(
            last_user.content,
            images=last_user.images,
            documents=last_user.documents,
            _same_turn=True,
        )

    async def _handle_edit_message(self, content: str) -> None:
        """编辑最后一条用户消息：丢弃它和它之后的所有内容，用新文字重发。

        为简化实现，编辑会丢弃原消息上附带的图片/文档（和 Claude.ai 的编辑
        体验一致：改文字通常意味着换个问法，而不是保留旧附件重新提问）。
        """
        if self._streaming:
            return
        assert self.conversation is not None
        assert self.session is not None

        idx = self._find_last_human_message_index()
        if idx is None:
            return
        self.conversation.history = self.conversation.history[:idx]
        self._persisted_ids = {id(m) for m in self.conversation.history}
        self.session.rewrite(self.conversation.history)
        if self._turn_versions:
            self._turn_versions = self._turn_versions[: self._turn_versions_idx + 1]

        await self._broadcast({"type": "clear", "data": None})
        await self._replay_messages(self.conversation.history)
        await self._handle_user_message(content, _same_turn=True)

    async def _handle_switch_turn_version(self, index: int) -> None:
        """在 ‹ N/M › 导航里切换最后一轮的显示版本（仅内存，不重新请求模型）。"""
        if self._streaming:
            return
        if not self._turn_versions or not (0 <= index < len(self._turn_versions)):
            return
        if index == self._turn_versions_idx:
            return
        assert self.conversation is not None
        assert self.session is not None

        current_version = self._turn_versions[self._turn_versions_idx]
        prefix_len = len(self.conversation.history) - len(current_version)
        prefix = self.conversation.history[:prefix_len]

        # 先把当前显示的这版同步回列表（正常情况下已经是最新的，双保险）。
        self._turn_versions[self._turn_versions_idx] = list(self.conversation.history[prefix_len:])
        self._turn_versions_idx = index
        self.conversation.history = prefix + list(self._turn_versions[index])
        self._persisted_ids = {id(m) for m in self.conversation.history}
        self.session.rewrite(self.conversation.history)

        await self._broadcast({"type": "clear", "data": None})
        await self._replay_messages(self.conversation.history)
        await self._broadcast_turn_version()

    async def _handle_delete_session(self, session_id: str) -> None:
        """删除一个历史会话。

        若删除的正是当前活跃会话，先自动切换到最近使用的另一个会话（不存在
        则新建一个），确保删除后界面始终有一个可用的活跃会话——切换会关闭
        旧 session 的文件句柄，之后再删除磁盘文件才不会在 Windows 上因文件
        被占用而失败。
        """
        assert self.session_manager is not None

        if session_id == self.session_id:
            if self._streaming:
                await self._broadcast({
                    "type": "error",
                    "data": {"message": "Please wait for the current response to finish."},
                })
                return
            others = [m for m in self.session_manager.list() if m.id != session_id]
            if others:
                await self._handle_load_session(others[0].id)
            else:
                await self._handle_new_session()

        self.session_manager.delete(session_id)
        await self._broadcast_session_list()

    async def _handle_rename_session(self, session_id: str, title: str) -> None:
        """重命名一个历史会话（侧边栏手动改名，此后 append() 不会再自动覆盖标题）。"""
        assert self.session_manager is not None
        title = title[:TITLE_MAX_LENGTH]
        if self.session_manager.rename(session_id, title):
            if session_id == self.session_id and self.session is not None:
                self.session.meta.title = title
            await self._broadcast_session_list()

    async def _handle_compact(self) -> None:
        """处理 /compact 命令。"""
        if self.agent is None or self.conversation is None:
            await self._broadcast({
                "type": "error",
                "data": {"message": "Compact requires an active agent."},
            })
            await self._broadcast({"type": "command_done", "data": None})
            return

        await self._broadcast({
            "type": "system",
            "data": {"message": "Compacting conversation..."},
        })

        result = await self.agent.manual_compact(self.conversation)
        if isinstance(result, CompactNotification):
            await self._broadcast({
                "type": "system",
                "data": {"message": result.message},
            })
        elif isinstance(result, ErrorEvent):
            await self._broadcast({
                "type": "error",
                "data": {"message": result.message},
            })

        await self._broadcast({"type": "command_done", "data": None})

    # ------------------------------------------------------------------
    # UIController 协议实现（供命令系统回调）
    # ------------------------------------------------------------------

    def add_system_message(self, text: str) -> None:
        """同步接口 — 在事件循环中调度广播。"""
        asyncio.ensure_future(self._broadcast({
            "type": "system",
            "data": {"message": text},
        }))

    def send_user_message(self, text: str) -> None:
        """同步接口 — 注入用户消息并触发 agent。"""
        asyncio.create_task(self._handle_user_message(text))

    def set_plan_mode(self, enabled: bool) -> None:
        if self.agent is None:
            return
        if enabled:
            self.agent.set_permission_mode(PermissionMode.PLAN)
        else:
            self.agent.set_permission_mode(PermissionMode.DEFAULT)

    def get_token_count(self) -> tuple[int, int]:
        if self.agent:
            return self.agent.total_input_tokens, self.agent.total_output_tokens
        return 0, 0

    def refresh_status(self) -> None:
        pass  # Remote 模式不需要刷新 TUI 状态栏

    # ------------------------------------------------------------------
    # 权限响应处理
    # ------------------------------------------------------------------

    def _handle_permission_response(self, data: dict[str, Any]) -> None:
        """处理来自 Web UI 的权限回复。"""
        perm_id = data.get("id", "")
        response_str = data.get("response", "deny")

        future = self._pending_perms.pop(perm_id, None)
        if future is None or future.done():
            return

        # 映射字符串到枚举
        mapping = {
            "allow": PermissionResponse.ALLOW,
            "deny": PermissionResponse.DENY,
            "allowAlways": PermissionResponse.ALLOW_ALWAYS,
        }
        response = mapping.get(response_str, PermissionResponse.DENY)
        future.set_result(response)

    async def _expire_permission(
        self, perm_id: str, future: "asyncio.Future[PermissionResponse]"
    ) -> None:
        """浏览器端一直不回复时，超时按拒绝处理（ASK ≠ ALLOW）。"""
        try:
            await asyncio.sleep(PERMISSION_TIMEOUT_SECONDS)
        except asyncio.CancelledError:  # pragma: no cover
            return
        if future.done():
            return
        self._pending_perms.pop(perm_id, None)
        future.set_result(PermissionResponse.DENY)
        log.info("permission request timed out, denied: %s", perm_id)

    # ------------------------------------------------------------------
    # 辅助方法
    # ------------------------------------------------------------------

    def _build_command_list(self) -> list[dict[str, str]]:
        """构建命令列表，推送给前端用于斜杠命令菜单。"""
        result = []
        for cmd in self.command_registry.list_commands():
            result.append({
                "name": cmd.name,
                "description": cmd.description,
            })
        return result

    async def _broadcast(self, msg: dict[str, Any]) -> None:
        """向所有已连接的 WebSocket 客户端广播消息。"""
        if not self._connections:
            return
        data = json.dumps(msg, ensure_ascii=False)
        # 复制集合避免迭代中修改
        closed = []
        for ws in list(self._connections):
            try:
                await ws.send(data)
            except websockets.ConnectionClosed:
                closed.append(ws)
            except Exception:
                closed.append(ws)
        for ws in closed:
            self._connections.discard(ws)
