from __future__ import annotations

import logging
import subprocess
from dataclasses import dataclass

log = logging.getLogger(__name__)


@dataclass
class TmuxPaneInfo:
    pane_id: str
    session: str


class TmuxSpawnError(Exception):
    pass


def _run_tmux(*args: str) -> str:
    result = subprocess.run(
        ["tmux", *args],
        capture_output=True,
        text=True,
        timeout=10,
    )
    if result.returncode != 0:
        raise TmuxSpawnError(f"tmux {' '.join(args)} failed: {result.stderr.strip()}")
    return result.stdout.strip()


def build_cli_command(
    team_name: str,
    teammate_name: str,
    worktree_path: str,
    prompt: str,
    agent_type: str = "",
    model: str = "",
    mailbox_dir: str = "",
) -> str:
    parts = ["wendream", "-p"]
    parts.extend(["--work-dir", worktree_path])
    if agent_type:
        parts.extend(["--agent-type", agent_type])
    if model:
        parts.extend(["--model", model])
    env_parts = [
        f"WENDREAM_TEAM_NAME={team_name}",
        f"WENDREAM_TEAMMATE_NAME={teammate_name}",
    ]
    if mailbox_dir:
        env_parts.append(f"WENDREAM_MAILBOX_DIR={mailbox_dir}")
    env_prefix = " ".join(env_parts)
    cmd = " ".join(parts)
    full_prompt = prompt.replace("'", "'\\''")
    return f"{env_prefix} {cmd} '{full_prompt}'"


def spawn_tmux_teammate(
    team_name: str,
    teammate_name: str,
    worktree_path: str,
    prompt: str,
    agent_type: str = "",
    model: str = "",
    mailbox_dir: str = "",
) -> TmuxPaneInfo:
    window_name = f"{team_name}-{teammate_name}"

    cli_cmd = build_cli_command(
        team_name=team_name,
        teammate_name=teammate_name,
        worktree_path=worktree_path,
        prompt=prompt,
        agent_type=agent_type,
        model=model,
        mailbox_dir=mailbox_dir,
    )

    # Create a new tmux window (not split) for the teammate, matching Go
    _run_tmux("new-window", "-d", "-n", window_name, cli_cmd)

    log.info("Spawned tmux teammate %s in window %s", teammate_name, window_name)
    return TmuxPaneInfo(pane_id=window_name, session=team_name)


def send_keys_to_pane(pane_id: str, keys: str = "") -> None:
    try:
        _run_tmux("send-keys", "-t", pane_id, keys, "Enter")
    except TmuxSpawnError:
        log.warning("Failed to send keys to tmux pane %s", pane_id)


def kill_pane(pane_id: str) -> None:
    try:
        _run_tmux("kill-pane", "-t", pane_id)
    except TmuxSpawnError:
        pass
