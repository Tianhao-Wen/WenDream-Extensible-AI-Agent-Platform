
# Remote 模式的 Web 前端 HTML。
# 精心重制的高级视觉版本：玻璃拟态 + 渐变品牌色 + 流畅微动效。
# 与 wendream/remote.py 的 WebSocket 协议完全兼容（消息类型未改变）。

INDEX_HTML = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="wendream-version" content="__WENDREAM_VERSION__">
<title>WenDream AI智能体</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
:root {
  --bg: #f6f6fb;
  --bg-2: #ffffff;
  --surface: rgba(23,24,54,0.04);
  --surface-hover: rgba(23,24,54,0.065);
  --surface-solid: #ffffff;
  --border: rgba(23,24,54,0.09);
  --border-strong: rgba(23,24,54,0.15);
  --text: #23243a;
  --text-dim: #6d6f8a;
  --text-faint: #9598b3;
  --text-bright: #0f1022;
  --accent-1: #7c5cfa;
  --accent-2: #4f8ef7;
  --accent-grad: linear-gradient(135deg, var(--accent-1), var(--accent-2));
  --accent-glow: rgba(124,92,250,0.28);
  --green: #1fa971;
  --red: #e1476b;
  --yellow: #c9860f;
  --code-bg: #16172a;
  --code-text: #dcdcec;
  --code-text-dim: #9b9dbe;
  --code-border: rgba(255,255,255,0.09);
  --code-surface: rgba(255,255,255,0.07);
  --shadow-sm: rgba(30,34,80,0.08);
  --shadow-md: rgba(30,34,80,0.12);
  --shadow-lg: rgba(30,34,80,0.16);
  --radius-lg: 18px;
  --radius-md: 12px;
  --radius-sm: 8px;
}

html, body {
  height: 100%;
  background: var(--bg);
  color: var(--text);
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  font-size: 14.5px;
  -webkit-font-smoothing: antialiased;
}
code, pre, .mono { font-family: 'JetBrains Mono', 'SF Mono', Consolas, monospace; }

body {
  background:
    radial-gradient(900px 520px at 12% -8%, rgba(124,92,250,0.10), transparent 60%),
    radial-gradient(700px 520px at 100% 8%, rgba(79,142,247,0.09), transparent 55%),
    radial-gradient(600px 500px at 50% 110%, rgba(124,92,250,0.06), transparent 60%),
    var(--bg);
}

#app { display: flex; height: 100vh; width: 100%; position: relative; }

/* ── 侧边栏 ── */
#sidebar {
  width: 272px; flex-shrink: 0; height: 100vh; overflow: hidden;
  background: var(--surface-solid); border-right: 1px solid var(--border);
  display: flex; flex-direction: column; transition: width 0.2s ease;
}
#app.sidebar-collapsed #sidebar { width: 0; border-right: none; }
.sidebar-header { display: flex; align-items: center; gap: 9px; padding: 16px 16px 12px; flex-shrink: 0; }
.brand-mark-sm {
  width: 26px; height: 26px; border-radius: 8px; display: flex; align-items: center; justify-content: center;
  background: var(--accent-grad); box-shadow: 0 0 14px var(--accent-glow); flex-shrink: 0;
}
.sidebar-brand-title {
  font-weight: 800; font-size: 14.5px; letter-spacing: -0.01em; white-space: nowrap;
  background: var(--accent-grad); -webkit-background-clip: text; background-clip: text; color: transparent;
}
#new-chat-btn {
  margin: 4px 12px 14px; display: flex; align-items: center; gap: 8px; justify-content: center;
  padding: 9px 14px; border-radius: 10px; border: 1px solid var(--border-strong); background: var(--surface-solid);
  color: var(--text); font-family: inherit; font-weight: 600; font-size: 13px; cursor: pointer; flex-shrink: 0;
  box-shadow: 0 2px 8px var(--shadow-sm); transition: all 0.15s ease;
}
#new-chat-btn:hover { background: var(--surface-hover); transform: translateY(-1px); box-shadow: 0 4px 14px var(--shadow-sm); }
#new-chat-btn:active { transform: translateY(0); }
.sidebar-section-label {
  padding: 10px 16px 4px; font-size: 10.8px; font-weight: 700; color: var(--text-faint);
  text-transform: uppercase; letter-spacing: 0.06em;
}
#session-list { flex: 1; overflow-y: auto; padding: 0 8px 14px; }
#session-list::-webkit-scrollbar { width: 6px; }
#session-list::-webkit-scrollbar-track { background: transparent; }
#session-list::-webkit-scrollbar-thumb { background: var(--border-strong); border-radius: 3px; }
.session-empty-hint { padding: 10px 12px; font-size: 12px; color: var(--text-faint); }
.session-item {
  display: flex; align-items: center; gap: 4px; padding: 8px 8px 8px 10px; margin: 1px 0; border-radius: 8px;
  cursor: pointer; font-size: 12.8px; color: var(--text-dim); transition: background 0.12s ease, color 0.12s ease;
}
.session-item:hover { background: var(--surface-hover); color: var(--text); }
.session-item.active { background: rgba(124,92,250,0.11); color: var(--text-bright); font-weight: 600; }
.session-item .session-title { flex: 1; min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.session-delete, .session-rename {
  opacity: 0; flex-shrink: 0; width: 22px; height: 22px; border-radius: 6px; border: none; background: transparent;
  color: var(--text-faint); cursor: pointer; display: flex; align-items: center; justify-content: center;
  transition: all 0.12s ease;
}
.session-item:hover .session-delete, .session-item.active .session-delete,
.session-item:hover .session-rename, .session-item.active .session-rename { opacity: 1; }
.session-delete:hover { background: rgba(225,71,107,0.14); color: var(--red); }
.session-rename:hover { background: var(--surface-hover); color: var(--text); }
.session-title-input {
  flex: 1; min-width: 0; background: var(--bg-2); color: var(--text-bright); border: 1px solid var(--accent-1);
  border-radius: 6px; padding: 2px 6px; font-family: inherit; font-size: 12.8px; font-weight: 600;
}
#session-search-wrap { padding: 0 12px 8px; }
#session-search {
  width: 100%; box-sizing: border-box; background: var(--surface); border: 1px solid var(--border);
  border-radius: 8px; padding: 6px 10px; font-family: inherit; font-size: 12.5px; color: var(--text);
}
#session-search::placeholder { color: var(--text-faint); }
#session-search:focus { outline: none; border-color: var(--accent-1); }

#sidebar-backdrop { display: none; }

/* ── 主区域 ── */
#main { flex: 1; display: flex; flex-direction: column; height: 100vh; min-width: 0; }

/* ── 顶部状态栏 ── */
#status-bar {
  display: flex; align-items: center; justify-content: space-between; gap: 12px;
  padding: 12px 20px; flex-shrink: 0; position: sticky; top: 0; z-index: 20;
  background: rgba(246,246,251,0.78); backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px);
  border-bottom: 1px solid var(--border);
}
.status-left { display: flex; align-items: center; gap: 12px; min-width: 0; }
#sidebar-toggle-btn {
  width: 32px; height: 32px; border-radius: 8px; border: 1px solid var(--border); background: var(--surface);
  color: var(--text-dim); cursor: pointer; display: flex; align-items: center; justify-content: center;
  flex-shrink: 0; transition: all 0.15s ease;
}
#sidebar-toggle-btn:hover { background: var(--surface-hover); color: var(--text); }
.brand-sub { font-size: 11.5px; color: var(--text-faint); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; min-width: 0; display: none !important; }
.status-right { display: flex; align-items: center; gap: 10px; flex-shrink: 0; }
.pill {
  display: flex; align-items: center; gap: 6px; padding: 5px 10px; border-radius: 100px;
  font-size: 11.5px; color: var(--text-dim); background: var(--surface); border: 1px solid var(--border);
  white-space: nowrap;
}
#provider-select {
  padding: 5px 10px; border-radius: 100px; font-size: 11.5px; font-family: inherit;
  color: var(--text-dim); background: var(--surface); border: 1px solid var(--border); cursor: pointer;
}
#provider-select:focus { outline: none; border-color: var(--accent-1); }
.dot { display: inline-block; width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0; }
.dot.connected { background: var(--green); box-shadow: 0 0 8px var(--green); animation: pulse-dot 2s ease-in-out infinite; }
.dot.disconnected { background: var(--red); }
@keyframes pulse-dot { 0%,100% { opacity: 1; } 50% { opacity: 0.45; } }

/* ── 消息区域 ── */
#messages-wrap { flex: 1; overflow: hidden; position: relative; }
#messages {
  height: 100%; overflow-y: auto; scroll-behavior: smooth;
}
#messages::-webkit-scrollbar { width: 8px; }
#messages::-webkit-scrollbar-track { background: transparent; }
#messages::-webkit-scrollbar-thumb { background: var(--border-strong); border-radius: 4px; }
#messages::-webkit-scrollbar-thumb:hover { background: rgba(23,24,54,0.28); }
#messages-col { max-width: 820px; margin: 0 auto; min-height: 100%; box-sizing: border-box; padding: 24px 24px 12px; }

@keyframes fadeInUp { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }

/* ── 空状态欢迎页 ── */
#empty-state {
  height: 100%; display: flex; flex-direction: column; align-items: center; justify-content: center;
  text-align: center; padding: 20px; gap: 6px; animation: fadeInUp 0.4s ease;
}
#empty-state .hero-mark {
  width: 64px; height: 64px; border-radius: 20px; display: flex; align-items: center; justify-content: center;
  background: var(--accent-grad); box-shadow: 0 0 40px var(--accent-glow); margin-bottom: 18px;
}
#empty-state h1 {
  font-size: 24px; font-weight: 800; letter-spacing: -0.02em;
  background: var(--accent-grad); -webkit-background-clip: text; background-clip: text; color: transparent;
  margin-bottom: 6px;
}
#empty-state p { color: var(--text-dim); font-size: 13.5px; max-width: 380px; margin-bottom: 22px; }
.hero-chips { display: flex; flex-wrap: wrap; gap: 8px; justify-content: center; max-width: 480px; }
.hero-chip {
  padding: 8px 14px; border-radius: 100px; border: 1px solid var(--border); background: var(--surface);
  color: var(--text-dim); font-size: 12.5px; cursor: pointer; transition: all 0.15s ease;
}
.hero-chip:hover { background: var(--surface-hover); border-color: var(--border-strong); color: var(--text); transform: translateY(-1px); }

/* ── 消息行（用户 / 助手） ── */
.msg-row { display: flex; gap: 10px; margin-bottom: 22px; animation: fadeInUp 0.25s ease; }
.avatar {
  width: 26px; height: 26px; border-radius: 8px; flex-shrink: 0;
  display: flex; align-items: center; justify-content: center; margin-top: 2px;
}
.avatar.assistant { background: var(--accent-grad); box-shadow: 0 0 12px var(--accent-glow); }
.avatar.user { background: var(--surface-solid); border: 1px solid var(--border-strong); color: var(--text-dim); font-size: 11px; font-weight: 700; }

.msg-row.user { flex-direction: row-reverse; }
.msg-row.user .col { align-items: flex-end; display: flex; flex-direction: column; max-width: 76%; }
.msg-row.assistant .col { flex: 1; min-width: 0; }

.bubble-user {
  background: var(--accent-grad); color: #0c0c16; font-weight: 500;
  padding: 10px 14px; border-radius: 16px 16px 4px 16px; white-space: pre-wrap; line-height: 1.55;
}
.msg-user-actions { display: flex; align-items: center; gap: 6px; margin-top: 4px; align-self: flex-end; }
.msg-edit-btn {
  opacity: 0; display: flex; align-items: center; gap: 4px;
  background: transparent; border: none; color: var(--text-faint); cursor: pointer; font-size: 11px;
  padding: 2px 4px; transition: opacity 0.12s ease, color 0.12s ease;
}
.msg-row.user:hover .msg-edit-btn { opacity: 1; }
.msg-edit-btn:hover { color: var(--text); }
.turn-version-nav { display: none; align-items: center; gap: 1px; font-size: 11px; color: var(--text-faint); }
.turn-version-nav.show { display: flex; }
.turn-version-nav button {
  background: transparent; border: none; color: var(--text-faint); cursor: pointer; padding: 2px 3px;
  border-radius: 4px; font-size: 12px; line-height: 1; display: flex; align-items: center;
}
.turn-version-nav button:hover:not(:disabled) { background: var(--surface); color: var(--text); }
.turn-version-nav button:disabled { opacity: 0.3; cursor: default; }
.turn-version-nav span { padding: 0 2px; white-space: nowrap; }
.msg-edit-area {
  width: 100%; max-width: 420px; box-sizing: border-box; background: var(--bg-2); color: var(--text-bright);
  border: 1px solid var(--accent-1); border-radius: var(--radius-md); padding: 10px 12px;
  font-family: inherit; font-size: 14px; line-height: 1.55; resize: vertical; min-height: 60px;
}
.msg-edit-actions { display: flex; gap: 6px; justify-content: flex-end; margin-top: 6px; }
.msg-edit-actions button {
  padding: 5px 12px; border-radius: 8px; border: 1px solid var(--border); cursor: pointer;
  font-family: inherit; font-size: 12px; font-weight: 600; background: var(--surface); color: var(--text-dim);
}
.msg-edit-actions .btn-save { background: var(--accent-grad); color: #0c0c16; border: none; }
.msg-retry-btn {
  display: inline-flex; align-items: center; gap: 4px; margin-left: 8px; background: transparent;
  border: none; color: var(--text-faint); cursor: pointer; font-size: 11.5px; padding: 2px 6px;
  border-radius: 6px; transition: all 0.12s ease;
}
.msg-retry-btn:hover { background: var(--surface); color: var(--text); }

.content { color: var(--text); line-height: 1.7; }
.content > *:first-child { margin-top: 0 !important; }
.content p { margin-bottom: 10px; }
.content code {
  background: var(--code-bg); padding: 2px 6px; border-radius: 4px;
  font-size: 12.8px; border: 1px solid var(--code-border); color: #d7c9ff;
}
.content pre {
  background: var(--code-bg); border-radius: var(--radius-sm);
  margin: 10px 0; border: 1px solid var(--code-border); overflow: hidden;
  box-shadow: 0 6px 20px var(--shadow-sm);
}
.content pre code { background: none; border: none; padding: 14px; display: block; overflow-x: auto; font-size: 12.8px; line-height: 1.6; color: var(--code-text); }
.code-bar {
  display: flex; align-items: center; justify-content: space-between;
  padding: 6px 12px; border-bottom: 1px solid var(--code-border); background: rgba(255,255,255,0.03);
}
.code-lang { font-size: 11px; color: var(--code-text-dim); text-transform: uppercase; letter-spacing: 0.04em; }
.code-copy {
  font-size: 11px; color: var(--code-text-dim); background: var(--code-surface); border: 1px solid var(--code-border);
  border-radius: 6px; padding: 3px 9px; cursor: pointer; font-family: inherit; transition: all 0.15s ease;
}
.code-copy:hover { background: rgba(255,255,255,0.14); color: var(--code-text); }

.content ul, .content ol { padding-left: 22px; margin: 8px 0; }
.content li { margin: 4px 0; }
.content h1, .content h2, .content h3 { color: var(--text-bright); margin: 16px 0 8px; font-weight: 700; letter-spacing: -0.01em; }
.content h1 { font-size: 19px; } .content h2 { font-size: 16.5px; } .content h3 { font-size: 15px; }
.content a { color: var(--accent-2); text-decoration: none; border-bottom: 1px solid rgba(79,142,247,0.4); }
.content a:hover { border-bottom-color: var(--accent-2); }
.content blockquote {
  border-left: 3px solid var(--accent-1); padding: 4px 14px; color: var(--text-dim); margin: 10px 0;
  background: var(--surface); border-radius: 0 8px 8px 0;
}
.content hr { border: none; border-top: 1px solid var(--border); margin: 14px 0; }
.content table { border-collapse: collapse; margin: 10px 0; width: 100%; font-size: 13px; }
.content th, .content td { border: 1px solid var(--border); padding: 7px 12px; text-align: left; }
.content th { background: var(--surface); color: var(--text-bright); font-weight: 600; }
.content tr:nth-child(even) td { background: rgba(23,24,54,0.02); }

/* hljs 简化配色，贴合品牌色（代码块始终为深色，与主题无关） */
.hljs-keyword, .hljs-tag, .hljs-selector-tag { color: #8b9dfc; }
.hljs-string, .hljs-attr, .hljs-symbol, .hljs-addition { color: #a3e2a3; }
.hljs-comment, .hljs-quote { color: var(--code-text-dim); font-style: italic; }
.hljs-number, .hljs-literal { color: #f0b859; }
.hljs-title, .hljs-function, .hljs-name, .hljs-section { color: #7bc9f0; }
.hljs-built_in, .hljs-type, .hljs-class { color: #d7c9ff; }
.hljs-variable, .hljs-params, .hljs-attribute { color: #dcdcec; }
.hljs-deletion { color: var(--red); }

.msg-system { color: var(--text-faint); font-size: 12.5px; white-space: pre-wrap; margin: 6px 0 18px; padding-left: 36px; }
.msg-error {
  color: var(--red); font-size: 13px; margin: 6px 0 18px; padding: 10px 14px;
  background: rgba(225,71,107,0.07); border: 1px solid rgba(225,71,107,0.22); border-radius: var(--radius-sm);
  display: flex; align-items: center; gap: 8px;
}

/* ── 工具调用卡片 ── */
.tool-block {
  background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius-md);
  margin: 6px 0 18px 36px; overflow: hidden; transition: border-color 0.15s ease;
}
.tool-block:hover { border-color: var(--border-strong); }
.tool-header {
  display: flex; align-items: center; gap: 9px;
  padding: 9px 13px; cursor: pointer; user-select: none; font-size: 12.8px;
}
.tool-header:hover { background: var(--surface-hover); }
.tool-header .chev { color: var(--text-faint); transition: transform 0.2s ease; display: flex; }
.tool-header .chev.expanded { transform: rotate(90deg); }
.tool-icon {
  width: 20px; height: 20px; border-radius: 6px; display: flex; align-items: center; justify-content: center;
  background: rgba(79,142,247,0.12); color: var(--accent-2); flex-shrink: 0;
}
.tool-header .name { color: var(--text-bright); font-weight: 600; }
.tool-header .preview {
  color: var(--text-faint); font-size: 12px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  flex: 1; min-width: 0;
}
.tool-header .status { margin-left: auto; font-size: 11.5px; flex-shrink: 0; display: flex; align-items: center; gap: 4px; padding: 2px 8px; border-radius: 100px; }
.tool-header .status.ok { color: var(--green); background: rgba(31,169,113,0.1); }
.tool-header .status.err { color: var(--red); background: rgba(225,71,107,0.1); }
.tool-header .status.loading { color: var(--yellow); background: rgba(201,134,15,0.1); }
.spin { animation: spin 0.9s linear infinite; display: inline-block; }
@keyframes spin { to { transform: rotate(360deg); } }
.tool-body {
  max-height: 0; overflow: hidden; transition: max-height 0.25s ease;
  border-top: 0 solid var(--border); font-size: 12px; color: var(--text-dim);
}
.tool-body.show { max-height: 320px; overflow-y: auto; border-top: 1px solid var(--border); }
.tool-body .inner { padding: 10px 13px; white-space: pre-wrap; word-break: break-word; }
.tool-body .args-label { color: var(--accent-2); font-weight: 600; margin-bottom: 4px; display: block; }

/* ── 思考过程 ── */
.thinking-block {
  background: transparent; border: 1px dashed var(--border); border-radius: var(--radius-md);
  margin: 6px 0 18px 36px; overflow: hidden;
}
.thinking-header {
  display: flex; align-items: center; gap: 8px; padding: 8px 13px; cursor: pointer; user-select: none;
  font-size: 12.5px; color: var(--text-faint);
}
.thinking-header:hover { background: var(--surface); }
.thinking-header .chev { transition: transform 0.2s ease; display: flex; }
.thinking-header .chev.expanded { transform: rotate(90deg); }
.think-glyph { animation: pulse-dot 1.4s ease-in-out infinite; }
.thinking-body {
  max-height: 0; overflow: hidden; transition: max-height 0.25s ease; border-top: 0 solid var(--border);
}
.thinking-body.show { max-height: 280px; overflow-y: auto; border-top: 1px solid var(--border); }
.thinking-body .inner { padding: 10px 13px; white-space: pre-wrap; color: var(--text-faint); font-style: italic; font-size: 12px; }

/* ── 弹窗（权限 / 提问） ── */
.dialog-card {
  background: var(--surface-solid); border: 1px solid var(--border-strong); border-left: 3px solid var(--yellow);
  border-radius: var(--radius-md); padding: 16px; margin: 6px 0 18px 36px;
  box-shadow: 0 8px 24px var(--shadow-md); animation: fadeInUp 0.2s ease;
}
.dialog-card.answered { border-left-color: var(--border); }
.dialog-title { display: flex; align-items: center; gap: 8px; color: var(--text-bright); font-weight: 700; font-size: 13.5px; margin-bottom: 10px; }
.dialog-desc { color: var(--text-dim); margin-bottom: 14px; font-size: 13px; white-space: pre-wrap; line-height: 1.6; }
.dialog-actions { display: flex; gap: 8px; flex-wrap: wrap; }
.dialog-actions button {
  padding: 7px 16px; border-radius: 8px; border: 1px solid var(--border);
  cursor: pointer; font-family: inherit; font-size: 12.8px; font-weight: 600; transition: all 0.15s ease;
}
.dialog-actions button:hover { transform: translateY(-1px); }
.btn-allow { background: var(--green); color: #062; border-color: var(--green); }
.btn-deny { background: transparent; color: var(--red); border-color: rgba(225,71,107,0.4); }
.btn-always { background: transparent; color: var(--accent-2); border-color: rgba(79,142,247,0.4); }
.q-block { margin-bottom: 14px; }
.q-text { margin-bottom: 8px; color: var(--text-bright); font-size: 13px; font-weight: 500; }
.q-option {
  display: flex; align-items: baseline; gap: 8px; margin: 5px 0; cursor: pointer; padding: 6px 10px;
  border-radius: 8px; border: 1px solid transparent; transition: all 0.15s ease; font-size: 12.8px;
}
.q-option:hover { background: var(--surface); border-color: var(--border); }
.q-option input[type="radio"] { accent-color: var(--accent-1); }
.q-option .opt-label { color: var(--accent-2); font-weight: 600; }
.q-option .opt-desc { color: var(--text-faint); font-size: 12px; }
.q-other-input {
  background: var(--bg-2); color: var(--text); border: 1px solid var(--border); border-radius: 6px;
  padding: 5px 9px; font-family: inherit; font-size: 12.5px; width: 260px; margin-left: 4px;
}

/* ── 完成指示 ── */
.done-indicator { color: var(--text-faint); font-size: 11.5px; margin: 4px 0 20px 36px; display: flex; align-items: center; gap: 6px; }

/* ── 流式光标 ── */
.cursor { display: inline-block; width: 2px; height: 15px; background: var(--accent-2); margin-left: 2px; vertical-align: -2px; animation: blink 0.9s step-end infinite; }
@keyframes blink { 50% { opacity: 0; } }

/* ── 回到底部悬浮按钮 ── */
.scroll-fab {
  position: absolute; bottom: 14px; left: 50%; transform: translateX(-50%);
  background: var(--surface-solid); border: 1px solid var(--border-strong); color: var(--text);
  padding: 7px 16px; border-radius: 100px; font-size: 12px; cursor: pointer; z-index: 15;
  box-shadow: 0 6px 20px var(--shadow-md); display: none; align-items: center; gap: 6px;
  font-family: inherit; transition: all 0.15s ease;
}
.scroll-fab:hover { background: var(--surface-hover); transform: translateX(-50%) translateY(-2px); }

/* ── 斜杠命令菜单 ── */
#slash-menu {
  display: none; position: absolute; bottom: 100%; left: 0; right: 0;
  background: var(--surface-solid); border: 1px solid var(--border-strong);
  border-radius: var(--radius-md); margin-bottom: 8px; max-height: 260px;
  overflow-y: auto; box-shadow: 0 -8px 28px var(--shadow-lg); padding: 6px;
}
#slash-menu.show { display: block; }
.slash-item {
  padding: 8px 10px; cursor: pointer; display: flex; gap: 10px; align-items: baseline;
  border-radius: 8px; border-left: 2px solid transparent;
}
.slash-item:hover, .slash-item.active { background: var(--surface-hover); border-left-color: var(--accent-1); }
.slash-item .cmd-name { color: var(--accent-2); font-weight: 700; white-space: nowrap; font-size: 12.8px; }
.slash-item .cmd-desc { color: var(--text-faint); font-size: 12px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

/* ── 输入区域 ── */
#input-outer { flex-shrink: 0; padding: 12px 20px 18px; }
#input-inner { max-width: 820px; margin: 0 auto; position: relative; }
#input-area {
  display: flex; gap: 8px; align-items: flex-end; background: var(--surface-solid);
  border: 1px solid var(--border); border-radius: var(--radius-lg); padding: 8px 8px 8px 16px;
  box-shadow: 0 10px 30px var(--shadow-md); transition: border-color 0.15s ease, box-shadow 0.15s ease;
}
#input-area:focus-within { border-color: var(--accent-1); box-shadow: 0 10px 30px var(--shadow-md), 0 0 0 3px rgba(124,92,250,0.14); }
#input-area textarea {
  flex: 1; background: transparent; color: var(--text-bright); border: none; outline: none;
  font-family: inherit; font-size: 14px; resize: none; min-height: 26px; max-height: 200px;
  line-height: 1.55; padding: 8px 0;
}
#input-area textarea::placeholder { color: var(--text-faint); }
#send-btn {
  background: var(--accent-grad); color: #0c0c16; border: none;
  border-radius: 12px; width: 40px; height: 40px; cursor: pointer; flex-shrink: 0;
  display: flex; align-items: center; justify-content: center; transition: all 0.15s ease;
  box-shadow: 0 4px 14px var(--accent-glow);
}
#send-btn:hover { filter: brightness(1.08); transform: translateY(-1px); }
#send-btn:disabled { opacity: 0.35; cursor: not-allowed; box-shadow: none; transform: none; }
#send-btn.stop-mode { background: var(--surface); color: var(--red); box-shadow: none; border: 1px solid rgba(225,71,107,0.4); }
#send-btn.stop-mode:disabled { opacity: 1; cursor: pointer; }
#upload-btn {
  background: var(--surface); color: var(--text-dim); border: 1px solid var(--border);
  border-radius: 12px; width: 40px; height: 40px; cursor: pointer; flex-shrink: 0;
  display: flex; align-items: center; justify-content: center; transition: all 0.15s ease;
}
#upload-btn:hover { background: var(--surface-hover); color: var(--text); }
#image-preview-row {
  display: none; flex-wrap: wrap; gap: 8px; padding: 0 4px 10px;
}
#image-preview-row.show { display: flex; }
.image-preview-item { position: relative; width: 56px; height: 56px; flex-shrink: 0; }
.image-preview-item img {
  width: 100%; height: 100%; object-fit: cover; border-radius: var(--radius-sm);
  border: 1px solid var(--border-strong);
}
.image-preview-remove {
  position: absolute; top: -6px; right: -6px; width: 18px; height: 18px; border-radius: 50%;
  background: var(--red); color: #fff; border: none; cursor: pointer; font-size: 11px;
  line-height: 1; display: flex; align-items: center; justify-content: center;
}
.file-chip {
  display: flex; align-items: center; gap: 6px; padding: 6px 10px 6px 8px;
  border-radius: var(--radius-sm); background: var(--surface); border: 1px solid var(--border-strong);
  font-size: 12px; color: var(--text-dim); max-width: 220px;
}
.file-chip .file-chip-icon { flex-shrink: 0; font-size: 14px; }
.file-chip .file-chip-name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.file-chip .file-chip-remove {
  flex-shrink: 0; width: 16px; height: 16px; border-radius: 50%; background: var(--border-strong);
  color: var(--text); border: none; cursor: pointer; font-size: 10px; line-height: 1;
  display: flex; align-items: center; justify-content: center; margin-left: 2px;
}
.file-chip .file-chip-remove:hover { background: var(--red); color: #fff; }
.bubble-user-files { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 6px; justify-content: flex-end; }
.bubble-user-files .file-chip { background: var(--surface-solid); }
.bubble-user-images { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 6px; justify-content: flex-end; }
.bubble-user-images img {
  max-width: 200px; max-height: 200px; border-radius: var(--radius-md);
  border: 1px solid var(--border-strong); display: block; cursor: zoom-in;
}
#image-lightbox {
  display: none; position: fixed; inset: 0; z-index: 100; background: rgba(10,10,18,0.82);
  align-items: center; justify-content: center; padding: 40px; cursor: zoom-out;
}
#image-lightbox.show { display: flex; }
#image-lightbox img { max-width: 100%; max-height: 100%; border-radius: var(--radius-md); box-shadow: 0 20px 60px rgba(0,0,0,0.5); }
#lightbox-close {
  position: absolute; top: 18px; right: 22px; width: 36px; height: 36px; border-radius: 50%;
  background: rgba(255,255,255,0.12); border: none; color: #fff; cursor: pointer; font-size: 18px;
  display: flex; align-items: center; justify-content: center;
}
#lightbox-close:hover { background: rgba(255,255,255,0.22); }
#confirm-modal {
  display: none; position: fixed; inset: 0; z-index: 110; background: rgba(10,10,18,0.55);
  backdrop-filter: blur(4px); -webkit-backdrop-filter: blur(4px);
  align-items: center; justify-content: center; padding: 20px;
}
#confirm-modal.show { display: flex; }
.confirm-card {
  background: var(--surface-solid); border: 1px solid var(--border-strong); border-radius: var(--radius-lg);
  padding: 22px 24px; max-width: 380px; width: 100%; box-shadow: 0 24px 64px rgba(0,0,0,0.35);
  animation: fadeInUp 0.18s ease;
}
.confirm-title { font-size: 15.5px; font-weight: 700; color: var(--text-bright); margin-bottom: 8px; }
.confirm-desc { font-size: 13px; color: var(--text-dim); line-height: 1.55; margin-bottom: 20px; }
.confirm-actions { display: flex; justify-content: flex-end; gap: 8px; }
.confirm-actions button {
  padding: 8px 16px; border-radius: 9px; border: 1px solid var(--border); cursor: pointer;
  font-family: inherit; font-size: 13px; font-weight: 600; background: var(--surface); color: var(--text);
  transition: all 0.12s ease;
}
.confirm-actions .btn-cancel:hover { background: var(--surface-hover); }
.confirm-actions .btn-danger { background: var(--red); border-color: var(--red); color: #fff; }
.confirm-actions .btn-danger:hover { filter: brightness(1.1); }
#drop-overlay {
  display: none; position: fixed; inset: 0; z-index: 90; background: rgba(124,92,250,0.10);
  backdrop-filter: blur(2px); align-items: center; justify-content: center;
}
#drop-overlay.show { display: flex; }
#drop-overlay .drop-card {
  border: 2px dashed var(--accent-1); border-radius: var(--radius-lg); padding: 40px 56px;
  background: var(--surface-solid); color: var(--text-bright); font-weight: 700; font-size: 15px;
  display: flex; flex-direction: column; align-items: center; gap: 10px; pointer-events: none;
}
#input-hint { text-align: center; font-size: 10.8px; color: var(--text-faint); margin-top: 8px; }
#input-hint kbd {
  background: var(--surface); border: 1px solid var(--border); border-radius: 4px; padding: 1px 5px;
  font-family: inherit; font-size: 10px; color: var(--text-dim);
}

@media (max-width: 860px) {
  #sidebar {
    position: fixed; top: 0; left: 0; width: 272px; height: 100%; z-index: 60;
    transform: translateX(0); transition: transform 0.25s ease; box-shadow: 0 0 40px var(--shadow-lg);
  }
  #app.sidebar-collapsed #sidebar { width: 272px; transform: translateX(-100%); border-right: 1px solid var(--border); }
  #sidebar-backdrop {
    display: none; position: fixed; inset: 0; background: rgba(15,16,34,0.35); z-index: 55;
  }
  #app:not(.sidebar-collapsed) #sidebar-backdrop { display: block; }
}

@media (max-width: 640px) {
  #status-bar, #input-outer { padding-left: 12px; padding-right: 12px; }
  #messages-col { padding-left: 12px; padding-right: 12px; }
  .msg-row.user .col { max-width: 88%; }
  #input-hint { display: none; }
  .brand-sub { display: none; }
}
</style>
</head>
<body>
<div id="app">
  <aside id="sidebar">
    <div class="sidebar-header">
      <div class="brand-mark-sm">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
          <path d="M12 4c-.86 0-1.62.35-2.18.95L6.8 2.3l.55 4.3C5.1 7.85 3.6 10.35 3.6 13.2 3.6 18 7.35 21.7 12 21.7s8.4-3.7 8.4-8.5c0-2.85-1.5-5.35-3.75-6.6l.55-4.3-3.02 2.65C13.62 4.35 12.86 4 12 4z" fill="#fff"/>
          <circle cx="9.1" cy="13.6" r="1.15" fill="#161320"/>
          <circle cx="14.9" cy="13.6" r="1.15" fill="#161320"/>
        </svg>
      </div>
      <span class="sidebar-brand-title">WenDream</span>
    </div>
    <button id="new-chat-btn">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none"><path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>
      新对话
    </button>
    <div id="session-search-wrap"><input type="text" id="session-search" placeholder="搜索会话..."></div>
    <div id="session-list"><div class="session-empty-hint">暂无会话</div></div>
  </aside>
  <div id="sidebar-backdrop"></div>
  <div id="image-lightbox">
    <button id="lightbox-close" title="Close">✕</button>
    <img id="lightbox-img" src="" alt="">
  </div>
  <div id="drop-overlay"><div class="drop-card">📎 Drop files here to attach</div></div>
  <div id="confirm-modal">
    <div class="confirm-card">
      <div class="confirm-title" id="confirm-title"></div>
      <div class="confirm-desc" id="confirm-desc"></div>
      <div class="confirm-actions">
        <button class="btn-cancel" id="confirm-cancel-btn" type="button">Cancel</button>
        <button class="btn-danger" id="confirm-ok-btn" type="button">Delete</button>
      </div>
    </div>
  </div>

  <div id="main">
    <div id="status-bar">
      <div class="status-left">
        <button id="sidebar-toggle-btn" title="Toggle sidebar">
          <svg width="17" height="17" viewBox="0 0 24 24" fill="none"><rect x="3" y="4" width="18" height="16" rx="3" stroke="currentColor" stroke-width="1.8"/><line x1="9" y1="4" x2="9" y2="20" stroke="currentColor" stroke-width="1.8"/></svg>
        </button>
        <span class="brand-sub" id="cwd-info" aria-hidden="true"></span>
      </div>
      <div class="status-right">
        <select id="provider-select" title="Model"></select>
        <span class="pill" id="token-info" style="display:none;"></span>
        <span class="pill" id="conn-status"><span class="dot disconnected"></span>连接中…</span>
      </div>
    </div>

    <div id="messages-wrap">
      <div id="messages"><div id="messages-col"></div></div>
      <button class="scroll-fab" id="scroll-fab">↓ New messages</button>
    </div>

    <div id="input-outer">
      <div id="input-inner">
        <div id="image-preview-row"></div>
        <div id="input-area">
          <div id="slash-menu"></div>
          <input type="file" id="file-input" accept="image/png,image/jpeg,image/gif,image/webp,application/pdf,.txt,.md,.py,.js,.ts,.jsx,.tsx,.json,.yaml,.yml,.csv,.html,.css,.java,.c,.cpp,.h,.go,.rs,.rb,.php,.sh,.sql,.xml,.log,.toml,.ini" multiple style="display:none;">
          <button id="upload-btn" title="Upload file">
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none"><path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66l-9.2 9.19a2 2 0 01-2.83-2.83l8.49-8.48" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </button>
          <textarea id="input" placeholder="输入消息给 WenDream…" rows="1"></textarea>
          <button id="send-btn" title="Send">
            <svg id="send-icon" width="17" height="17" viewBox="0 0 24 24" fill="none"><path d="M4 12l16-8-6 8 6 8-16-8z" fill="currentColor"/></svg>
          </button>
        </div>
        <div id="input-hint">Enter to send &nbsp;·&nbsp; <kbd>Shift</kbd>+<kbd>Enter</kbd> newline &nbsp;·&nbsp; <kbd>/</kbd> commands</div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js"></script>
<!-- XSS 防线：marked 不是 sanitizer，模型输出必须先过 DOMPurify 再进 innerHTML -->
<script src="https://cdn.jsdelivr.net/npm/dompurify@3.1.7/dist/purify.min.js"></script>
<script>
const appEl = document.getElementById('app');
const scrollWrap = document.getElementById('messages');
const messagesEl = document.getElementById('messages-col');
const inputEl = document.getElementById('input');
const sendBtn = document.getElementById('send-btn');
const sendIcon = document.getElementById('send-icon');
const connStatus = document.getElementById('conn-status');
const tokenInfo = document.getElementById('token-info');
const cwdInfo = document.getElementById('cwd-info');
const slashMenu = document.getElementById('slash-menu');
const uploadBtn = document.getElementById('upload-btn');
const fileInput = document.getElementById('file-input');
const imagePreviewRow = document.getElementById('image-preview-row');
const imageLightbox = document.getElementById('image-lightbox');
const lightboxImg = document.getElementById('lightbox-img');
const lightboxClose = document.getElementById('lightbox-close');
const dropOverlay = document.getElementById('drop-overlay');
const providerSelect = document.getElementById('provider-select');
const confirmModal = document.getElementById('confirm-modal');
const confirmTitleEl = document.getElementById('confirm-title');
const confirmDescEl = document.getElementById('confirm-desc');
const confirmCancelBtn = document.getElementById('confirm-cancel-btn');
const confirmOkBtn = document.getElementById('confirm-ok-btn');
const scrollFab = document.getElementById('scroll-fab');
const sidebarToggleBtn = document.getElementById('sidebar-toggle-btn');
const sidebarBackdrop = document.getElementById('sidebar-backdrop');
const newChatBtn = document.getElementById('new-chat-btn');
const sessionSearchEl = document.getElementById('session-search');
const sessionListEl = document.getElementById('session-list');

let currentSessionId = '';
let sessions = [];

let ws = null;
let streaming = false;
let allCommands = [];
let slashCursor = 0;
let slashFiltered = [];
let currentAssistantEl = null;
let currentStreamText = '';
let currentThinkingEl = null;
let currentThinkingText = '';
let autoScroll = true;
let pingTimer = null;
let connectedOnce = false;
let pendingImages = [];
let pendingDocuments = [];   // PDF：{media_type, data, name}
let pendingTextFiles = [];   // 纯文本/代码文件：{name, content}
let visionEnabled = false;
let lastUserActionsRow = null; // 只有最新一条用户消息才带编辑按钮/版本导航
let lastRetryBtn = null;       // 只有最新一条回复可重新生成
let currentTurnNavEl = null;   // 最新一条用户消息旁边的 ‹ N/M › 版本导航

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
const MAX_DOCUMENT_BYTES = 20 * 1024 * 1024;
const MAX_TEXT_FILE_BYTES = 300 * 1024;
const MAX_ATTACHMENTS_PER_MESSAGE = 5;
const ACCEPTED_IMAGE_TYPES = ['image/png', 'image/jpeg', 'image/gif', 'image/webp'];
const TEXT_FILE_EXTENSIONS = [
  'txt', 'md', 'py', 'js', 'ts', 'jsx', 'tsx', 'json', 'yaml', 'yml', 'csv',
  'html', 'css', 'java', 'c', 'cpp', 'h', 'go', 'rs', 'rb', 'php', 'sh',
  'sql', 'xml', 'log', 'toml', 'ini',
];

function attachmentCount() {
  return pendingImages.length + pendingDocuments.length + pendingTextFiles.length;
}

function classifyFile(file) {
  if (ACCEPTED_IMAGE_TYPES.includes(file.type)) return 'image';
  if (file.type === 'application/pdf') return 'pdf';
  const ext = (file.name.split('.').pop() || '').toLowerCase();
  if (file.type.startsWith('text/') || TEXT_FILE_EXTENSIONS.includes(ext)) return 'text';
  return 'unsupported';
}

if (typeof marked !== 'undefined') {
  marked.setOptions({ breaks: true, gfm: true });
}

const ICON_STOP = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none"><rect x="5" y="5" width="14" height="14" rx="3" fill="currentColor"/></svg>';
const ICON_SEND = '<svg width="17" height="17" viewBox="0 0 24 24" fill="none"><path d="M4 12l16-8-6 8 6 8-16-8z" fill="currentColor"/></svg>';

const EMPTY_STATE_HTML =
  '<div id="empty-state">' +
    '<div class="hero-mark"><svg width="30" height="30" viewBox="0 0 24 24" fill="none">' +
      '<path d="M12 4c-.86 0-1.62.35-2.18.95L6.8 2.3l.55 4.3C5.1 7.85 3.6 10.35 3.6 13.2 3.6 18 7.35 21.7 12 21.7s8.4-3.7 8.4-8.5c0-2.85-1.5-5.35-3.75-6.6l.55-4.3-3.02 2.65C13.62 4.35 12.86 4 12 4z" fill="#fff"/>' +
      '<circle cx="9.1" cy="13.6" r="1.3" fill="#0a0a12"/><circle cx="14.9" cy="13.6" r="1.3" fill="#0a0a12"/>' +
    '</svg></div>' +
    '<h1>WenDream</h1>' +
    '<p>你的智能助手，已在浏览器中就绪。你可以提问、总结内容、写作润色、规划任务，或让它协助你完成各种工作。</p>' +
    '<div class="hero-chips">' +
      '<span class="hero-chip" data-fill="总结这份资料的重点">总结资料</span>' +
      '<span class="hero-chip" data-fill="帮我润色这段文案">润色文案</span>' +
      '<span class="hero-chip" data-fill="帮我制定一个学习计划">学习计划</span>' +
      '<span class="hero-chip" data-fill="/help">/help</span>' +
    '</div>' +
  '</div>';

function resetEmptyState() {
  messagesEl.innerHTML = EMPTY_STATE_HTML;
  messagesEl.querySelectorAll('.hero-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      inputEl.value = chip.dataset.fill;
      inputEl.focus();
      inputEl.dispatchEvent(new Event('input'));
    });
  });
}

function hideEmptyState() {
  const es = document.getElementById('empty-state');
  if (es) es.remove();
}

function renderMarkdown(text) {
  if (typeof marked === 'undefined') return escapeHtml(text);

  let html = '';
  try {
    // 第一步：解析 markdown；同时把原始 HTML token 转义，去掉“未消毒 HTML”路径。
    const renderer = new marked.Renderer();
    renderer.html = (token) => escapeHtml(typeof token === 'string' ? token : (token && token.text) || '');
    html = marked.parse(text, { renderer: renderer });
  } catch (e) {
    return escapeHtml(text);
  }

  // 第二步：消毒。DOMPurify 不存在时（CDN 不可达/离线）直接典到纯文本，
  // 绝不把未消毒 HTML 写进 DOM。
  if (typeof DOMPurify === 'undefined') return escapeHtml(text);
  try {
    return DOMPurify.sanitize(html, SANITIZE_OPTIONS);
  } catch (e) {
    return escapeHtml(text);
  }
}

// 只保留 Markdown 实际会用到的标签；危险标签/属性与 javascript: 类 URL 一并禁止。
const SANITIZE_OPTIONS = {
  ALLOWED_TAGS: [
    'p','br','hr','strong','b','em','i','del','s','code','pre','blockquote',
    'ul','ol','li','h1','h2','h3','h4','h5','h6','a','img','table','thead',
    'tbody','tr','th','td','span','div','sup','sub'
  ],
  ALLOWED_ATTR: ['href','title','alt','src','class','align','colspan','rowspan','start'],
  ALLOW_DATA_ATTR: false,
  FORBID_TAGS: ['script','style','iframe','object','embed','form','input','button','link','meta','base','svg','math'],
  FORBID_ATTR: ['onerror','onload','onclick','onmouseover','onfocus','onbegin','style','srcdoc','formaction'],
  ALLOW_UNKNOWN_PROTOCOLS: false
};

function escapeHtml(s) {
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

// 属性值转义（用于 data-id / value 这类属性拼接）
function escapeAttr(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

function enhanceCodeBlocks(container) {
  container.querySelectorAll('pre > code').forEach((codeEl) => {
    const pre = codeEl.parentElement;
    if (pre.dataset.enhanced) return;
    pre.dataset.enhanced = '1';
    const m = (codeEl.className || '').match(/language-(\w+)/);
    const lang = m ? m[1] : 'text';
    const bar = document.createElement('div');
    bar.className = 'code-bar';
    const langSpan = document.createElement('span');
    langSpan.className = 'code-lang';
    langSpan.textContent = lang;
    const copyBtn = document.createElement('button');
    copyBtn.className = 'code-copy';
    copyBtn.type = 'button';
    copyBtn.textContent = 'Copy';
    copyBtn.addEventListener('click', () => {
      navigator.clipboard.writeText(codeEl.textContent).then(() => {
        copyBtn.textContent = 'Copied!';
        setTimeout(() => { copyBtn.textContent = 'Copy'; }, 1400);
      }).catch(() => {});
    });
    bar.appendChild(langSpan);
    bar.appendChild(copyBtn);
    pre.insertBefore(bar, codeEl);
    if (typeof hljs !== 'undefined') {
      try { hljs.highlightElement(codeEl); } catch(e) {}
    }
  });
}

// Remote 认证 token：从 URL fragment 取（#token=...），fragment 不会发到服务端，
// 取到后立即从地址栏抹掉，并保存在 sessionStorage。WS 用手势般的 subprotocol 携带，
// 避免 token 进入 URL query / 浏览器历史 / 服务端访问日志。
function readRemoteToken() {
  let token = '';
  try {
    const hash = location.hash || '';
    const m = hash.match(/[#&]token=([^&]+)/);
    if (m) token = decodeURIComponent(m[1]);
    if (token) {
      sessionStorage.setItem('wendream_remote_token', token);
      history.replaceState(null, '', location.pathname + location.search);
    } else {
      token = sessionStorage.getItem('wendream_remote_token') || '';
    }
  } catch (e) {
    token = '';
  }
  return token;
}

const REMOTE_TOKEN = readRemoteToken();

function connect() {
  if (pingTimer) { clearInterval(pingTimer); pingTimer = null; }
  if (ws) { try { ws.onclose = null; ws.close(); } catch(e) {} ws = null; }
  const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
  const protocols = ['wendream.v1'];
  if (REMOTE_TOKEN) protocols.push('wendream-token.' + REMOTE_TOKEN);
  ws = new WebSocket(proto + '//' + location.host + '/ws', protocols);

  ws.onopen = () => {
    connStatus.innerHTML = '<span class="dot connected"></span>已连接';
    pingTimer = setInterval(() => {
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'ping', data: {} }));
      }
    }, 10000);
  };

  ws.onclose = () => {
    connStatus.innerHTML = '<span class="dot disconnected"></span>重连中…';
    if (pingTimer) { clearInterval(pingTimer); pingTimer = null; }
    setTimeout(connect, 3000);
  };

  ws.onerror = () => {};

  ws.onmessage = (evt) => {
    const msg = JSON.parse(evt.data);
    handleMessage(msg);
  };
}

function handleMessage(msg) {
  switch (msg.type) {
    case 'connected':
      currentSessionId = msg.data.session;
      cwdInfo.textContent = msg.data.cwd;
      cwdInfo.title = 'Session: ' + msg.data.session + '\nCWD: ' + msg.data.cwd;
      connectedOnce = true;
      visionEnabled = !!msg.data.visionEnabled;
      // 上传按钮始终可见：纯文本/代码文件对任何模型都可用，只有图片/PDF 依赖 visionEnabled（在 handleFiles 里单独拦截）。
      if (msg.data.activeProvider) providerSelect.value = msg.data.activeProvider;
      renderSessionList();
      break;

    case 'commands':
      allCommands = msg.data || [];
      break;

    case 'providers':
      renderProviderSelect((msg.data && msg.data.providers) || [], msg.data && msg.data.active);
      break;

    case 'session_list':
      sessions = (msg.data && msg.data.sessions) || [];
      renderSessionList();
      break;

    case 'session_switched':
      currentSessionId = msg.data.id;
      cwdInfo.textContent = msg.data.cwd;
      cwdInfo.title = 'Session: ' + msg.data.id + (msg.data.cwd ? '\nCWD: ' + msg.data.cwd : '');
      tokenInfo.style.display = 'none';
      tokenInfo.textContent = '';
      if (msg.data.visionEnabled !== undefined) visionEnabled = !!msg.data.visionEnabled;
      if (msg.data.activeProvider) providerSelect.value = msg.data.activeProvider;
      renderSessionList();
      break;

    case 'system':
      addSystem(msg.data.message);
      break;

    case 'clear':
      resetEmptyState();
      lastUserActionsRow = null;
      lastRetryBtn = null;
      currentTurnNavEl = null;
      break;

    case 'turn_version':
      if (currentTurnNavEl) renderTurnVersionNav(currentTurnNavEl, msg.data.index, msg.data.total);
      break;

    case 'command_done':
      streaming = false;
      updateUI();
      break;

    case 'replay_user':
      addUser(msg.data.content, msg.data.images || [], msg.data.documents || []);
      break;

    case 'replay_assistant': {
      const el = addAssistant();
      updateAssistant(el, msg.data.content, false);
      attachRetryButton(el);
      break;
    }

    case 'stream_text':
      if (currentThinkingEl) { finalizeThinking(currentThinkingEl); currentThinkingEl = null; currentThinkingText = ''; }
      if (!currentAssistantEl) { currentAssistantEl = addAssistant(); currentStreamText = ''; }
      currentStreamText += msg.data.text;
      updateAssistant(currentAssistantEl, currentStreamText, true);
      break;

    case 'stream_end':
      if (currentAssistantEl) updateAssistant(currentAssistantEl, currentStreamText, false);
      currentAssistantEl = null;
      currentStreamText = '';
      break;

    case 'thinking_text':
      if (!currentThinkingEl) { currentThinkingEl = addThinking(); currentThinkingText = ''; }
      currentThinkingText += msg.data.text;
      currentThinkingEl.querySelector('.thinking-body .inner').textContent = currentThinkingText;
      break;

    case 'tool_use':
      if (currentThinkingEl) { finalizeThinking(currentThinkingEl); currentThinkingEl = null; currentThinkingText = ''; }
      addToolUse(msg.data);
      break;

    case 'tool_result':
      updateToolResult(msg.data);
      break;

    case 'permission_request':
      addPermissionDialog(msg.data);
      break;

    case 'ask_user':
      addAskUserDialog(msg.data);
      break;

    case 'turn_complete':
      break;

    case 'loop_complete': {
      if (currentAssistantEl) {
        updateAssistant(currentAssistantEl, currentStreamText, false);
        attachRetryButton(currentAssistantEl);
        currentAssistantEl = null;
        currentStreamText = '';
      }
      currentThinkingEl = null;
      currentThinkingText = '';
      const el = document.createElement('div');
      el.className = 'done-indicator';
      el.innerHTML = '✻ Done in ' + msg.data.elapsed.toFixed(1) + 's';
      messagesEl.appendChild(el);
      streaming = false;
      updateUI();
      scrollToBottom();
      break;
    }

    case 'usage':
      tokenInfo.style.display = 'flex';
      tokenInfo.textContent = '↑' + formatTokens(msg.data.inputTokens) + '  ↓' + formatTokens(msg.data.outputTokens);
      break;

    case 'error':
      addError(msg.data.message);
      streaming = false;
      updateUI();
      break;

    case 'compact':
      addSystem('⟳ ' + msg.data.message);
      break;

    case 'retry':
      addSystem('↻ Retrying: ' + msg.data.reason);
      break;
  }
}

function formatTokens(n) {
  if (n > 1000000) return (n/1000000).toFixed(1) + 'M';
  if (n > 1000) return (n/1000).toFixed(1) + 'K';
  return '' + n;
}

// 纯文本文件的内容直接拼进发给模型的 content 里（用这个格式包一层），
// 展示气泡时再用同一套规则把它抠掉，只留用户自己敲的文字 + 一个文件名 chip。
function buildFileBlock(name, content) {
  return '\n\n<file name="' + name.replace(/"/g, '&quot;') + '">\n' + content + '\n</file>';
}

const FILE_BLOCK_RE = /\n*<file name="([^"]*)">\n[\s\S]*?\n<\/file>/g;

function stripFileBlocks(text) {
  const fileNames = [];
  const display = text.replace(FILE_BLOCK_RE, (match, name) => {
    fileNames.push(name.replace(/&quot;/g, '"'));
    return '';
  }).trim();
  return { display, fileNames };
}

function addUser(text, images, documents) {
  hideEmptyState();
  const { display, fileNames } = stripFileBlocks(text || '');
  const row = document.createElement('div');
  row.className = 'msg-row user';
  row.innerHTML =
    '<div class="avatar user">' + initials() + '</div>' +
    '<div class="col"></div>';
  const col = row.querySelector('.col');

  if (images && images.length) {
    const imgRow = document.createElement('div');
    imgRow.className = 'bubble-user-images';
    images.forEach(img => {
      const el = document.createElement('img');
      el.src = 'data:' + img.media_type + ';base64,' + img.data;
      imgRow.appendChild(el);
    });
    col.appendChild(imgRow);
  }

  const fileChips = (documents || []).map(d => ({ icon: '📕', name: d.name || 'document.pdf' }))
    .concat(fileNames.map(n => ({ icon: '📄', name: n })));
  if (fileChips.length) {
    const fileRow = document.createElement('div');
    fileRow.className = 'bubble-user-files';
    fileChips.forEach(f => fileRow.appendChild(makeFileChip(f.icon, f.name, null)));
    col.appendChild(fileRow);
  }

  if (display) {
    const bubble = document.createElement('div');
    bubble.className = 'bubble-user';
    bubble.textContent = display;
    col.appendChild(bubble);

    // 只有「最新一条」用户消息才允许编辑/看版本导航——每次新增就把上一条的摘掉。
    if (lastUserActionsRow) lastUserActionsRow.remove();
    const actionsRow = document.createElement('div');
    actionsRow.className = 'msg-user-actions';
    const editBtn = document.createElement('button');
    editBtn.className = 'msg-edit-btn';
    editBtn.type = 'button';
    editBtn.title = 'Edit message';
    editBtn.innerHTML = ICON_PENCIL + ' Edit';
    editBtn.addEventListener('click', () => startEditMessage(bubble, col, display, editBtn, actionsRow));
    actionsRow.appendChild(editBtn);
    const navEl = document.createElement('div');
    navEl.className = 'turn-version-nav';
    actionsRow.appendChild(navEl);
    col.appendChild(actionsRow);
    lastUserActionsRow = actionsRow;
    currentTurnNavEl = navEl;
  }

  messagesEl.appendChild(row);
  scrollToBottom();
}

function startEditMessage(bubble, col, originalText, editBtn, actionsRow) {
  if (streaming) return;
  actionsRow.style.display = 'none';
  const textarea = document.createElement('textarea');
  textarea.className = 'msg-edit-area';
  textarea.value = originalText;
  const actions = document.createElement('div');
  actions.className = 'msg-edit-actions';
  const cancelBtn = document.createElement('button');
  cancelBtn.type = 'button';
  cancelBtn.textContent = 'Cancel';
  const saveBtn = document.createElement('button');
  saveBtn.type = 'button';
  saveBtn.className = 'btn-save';
  saveBtn.textContent = 'Save & Submit';
  actions.appendChild(cancelBtn);
  actions.appendChild(saveBtn);

  bubble.style.display = 'none';
  col.insertBefore(textarea, actionsRow);
  col.insertBefore(actions, actionsRow);
  textarea.focus();

  cancelBtn.addEventListener('click', () => {
    textarea.remove();
    actions.remove();
    bubble.style.display = '';
    actionsRow.style.display = '';
  });
  saveBtn.addEventListener('click', () => {
    const newText = textarea.value.trim();
    if (!newText || streaming) return;
    ws.send(JSON.stringify({ type: 'edit_message', data: { content: newText } }));
    streaming = true;
    updateUI();
  });
}

function initials() { return 'U'; }

// 只有「最新一条」助手回复才允许重新生成——每次新增就把上一个按钮摘掉。
function attachRetryButton(row) {
  if (lastRetryBtn) lastRetryBtn.remove();
  const btn = document.createElement('button');
  btn.className = 'msg-retry-btn';
  btn.type = 'button';
  btn.title = 'Regenerate this response';
  btn.innerHTML = '↻ Retry';
  btn.addEventListener('click', () => {
    if (streaming || !ws || ws.readyState !== WebSocket.OPEN) return;
    ws.send(JSON.stringify({ type: 'regenerate', data: {} }));
    streaming = true;
    updateUI();
  });
  row.querySelector('.col').appendChild(btn);
  lastRetryBtn = btn;
}

function switchTurnVersion(newIndex) {
  if (streaming || !ws || ws.readyState !== WebSocket.OPEN) return;
  ws.send(JSON.stringify({ type: 'switch_turn_version', data: { index: newIndex } }));
}

function renderTurnVersionNav(navEl, index, total) {
  if (total <= 1) { navEl.classList.remove('show'); navEl.innerHTML = ''; return; }
  navEl.classList.add('show');
  navEl.innerHTML =
    '<button type="button" data-dir="prev">‹</button>' +
    '<span>' + (index + 1) + '/' + total + '</span>' +
    '<button type="button" data-dir="next">›</button>';
  const prevBtn = navEl.querySelector('[data-dir="prev"]');
  const nextBtn = navEl.querySelector('[data-dir="next"]');
  prevBtn.disabled = index <= 0;
  nextBtn.disabled = index >= total - 1;
  prevBtn.addEventListener('click', () => switchTurnVersion(index - 1));
  nextBtn.addEventListener('click', () => switchTurnVersion(index + 1));
}

function addAssistant() {
  hideEmptyState();
  const row = document.createElement('div');
  row.className = 'msg-row assistant';
  row.innerHTML =
    '<div class="avatar assistant">' + brandGlyph() + '</div>' +
    '<div class="col"><div class="content"></div></div>';
  messagesEl.appendChild(row);
  scrollToBottom();
  return row;
}

function brandGlyph() {
  return '<svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M12 4c-.86 0-1.62.35-2.18.95L6.8 2.3l.55 4.3C5.1 7.85 3.6 10.35 3.6 13.2 3.6 18 7.35 21.7 12 21.7s8.4-3.7 8.4-8.5c0-2.85-1.5-5.35-3.75-6.6l.55-4.3-3.02 2.65C13.62 4.35 12.86 4 12 4z" fill="#fff"/><circle cx="9.1" cy="13.6" r="1.15" fill="#161320"/><circle cx="14.9" cy="13.6" r="1.15" fill="#161320"/></svg>';
}

function updateAssistant(row, text, isStreaming) {
  const contentEl = row.querySelector('.content');
  const thinkMatch = text.match(/^<think>([\s\S]*?)<\/think>\s*([\s\S]*)$/);
  let html = '';
  if (thinkMatch) {
    const thinkText = thinkMatch[1].trim();
    const bodyText = thinkMatch[2].trim();
    if (thinkText) html += thinkingHtml(thinkText, false);
    if (bodyText) html += renderMarkdown(bodyText);
    if (isStreaming) html += '<span class="cursor"></span>';
  } else if (text.startsWith('<think>') && isStreaming) {
    html += thinkingHtml(text.replace(/^<think>\s*/, ''), true);
    html += '<span class="cursor"></span>';
  } else {
    html = renderMarkdown(text);
    if (isStreaming) html += '<span class="cursor"></span>';
  }
  contentEl.innerHTML = html;
  enhanceCodeBlocks(contentEl);
  scrollToBottom();
}

function thinkingHtml(text, active) {
  return '<div class="thinking-block">' +
    '<div class="thinking-header" onclick="toggleThinking(this)">' +
      '<span class="chev">▶</span><span class="think-glyph">💭</span><span>' + (active ? 'Thinking…' : 'Thought') + '</span>' +
    '</div>' +
    '<div class="thinking-body"><div class="inner">' + escapeHtml(text) + '</div></div>' +
  '</div>';
}

function addThinking() {
  hideEmptyState();
  const row = document.createElement('div');
  row.className = 'thinking-block';
  row.innerHTML =
    '<div class="thinking-header" onclick="toggleThinking(this)">' +
      '<span class="chev">▶</span><span class="think-glyph">💭</span><span>Thinking…</span>' +
    '</div>' +
    '<div class="thinking-body"><div class="inner"></div></div>';
  messagesEl.appendChild(row);
  scrollToBottom();
  return row;
}

function finalizeThinking(el) {
  const label = el.querySelector('.thinking-header span:last-child');
  if (label) label.textContent = 'Thought';
}

function toggleThinking(header) {
  header.querySelector('.chev').classList.toggle('expanded');
  header.nextElementSibling.classList.toggle('show');
}

function addSystem(text) {
  hideEmptyState();
  const div = document.createElement('div');
  div.className = 'msg-system';
  div.textContent = text;
  messagesEl.appendChild(div);
  scrollToBottom();
}

function addError(text) {
  hideEmptyState();
  const div = document.createElement('div');
  div.className = 'msg-error';
  div.innerHTML = '✖ ' + escapeHtml(text);
  messagesEl.appendChild(div);
  scrollToBottom();
}

// ── 工具图标映射 ──
const TOOL_ICONS = {
  Bash: '&gt;_', Read: '📄', Write: '✎', Edit: '✎', Grep: '🔍', Glob: '🗂',
  WebFetch: '🌐', WebSearch: '🔎', Agent: '🤖', Task: '☑', AskUser: '❓',
};
function iconForTool(name) {
  for (const key in TOOL_ICONS) {
    if (name && name.indexOf(key) !== -1) return TOOL_ICONS[key];
  }
  return '⚙';
}

const toolElements = {};

function addToolUse(data) {
  hideEmptyState();
  const div = document.createElement('div');
  div.className = 'thinking-block tool-thought';

  const argsStr = data.args ? JSON.stringify(data.args, null, 2) : '';
  const toolSummary = data.toolName ? `Tool: ${data.toolName}` : 'Tool call';
  const contentParts = [];
  if (data.args) {
    if (data.args.command) contentParts.push('Command: ' + data.args.command);
    else if (data.args.file_path) contentParts.push('Path: ' + data.args.file_path);
    else if (data.args.pattern) contentParts.push('Pattern: ' + data.args.pattern);
    else if (data.args.path) contentParts.push('Path: ' + data.args.path);
  }
  if (argsStr) contentParts.push('Args:\n' + argsStr);

  div.innerHTML =
    '<div class="thinking-header" onclick="toggleThinking(this)">' +
      '<span class="chev">▶</span><span class="think-glyph">💭</span><span>Thought</span>' +
    '</div>' +
    '<div class="thinking-body"><div class="inner">' + escapeHtml((contentParts.length ? toolSummary + '\n\n' + contentParts.join('\n\n') : toolSummary)) + '</div></div>';

  messagesEl.appendChild(div);
  toolElements[data.toolName + '_' + (data.toolId || '')] = div;
  scrollToBottom();
}

function updateToolResult(data) {
  const key = data.toolName + '_' + (data.toolId || '');
  const div = toolElements[key];
  if (div) {
    const inner = div.querySelector('.inner');
    if (inner) {
      const resultText = (data.output || '').trim();
      const prefix = inner.textContent.trim() || 'Tool call';
      const lines = [prefix];
      if (resultText) lines.push('Result:\n' + (resultText.length > 5000 ? resultText.substring(0, 5000) + '\n… (truncated)' : resultText));
      inner.textContent = lines.join('\n\n');
    }
    delete toolElements[key];
  } else {
    const block = document.createElement('div');
    block.className = 'thinking-block tool-thought';
    const resultText = (data.output || '').trim();
    const body = resultText ? 'Result:\n' + (resultText.length > 5000 ? resultText.substring(0, 5000) + '\n… (truncated)' : resultText) : 'Tool result';
    block.innerHTML =
      '<div class="thinking-header" onclick="toggleThinking(this)">' +
        '<span class="chev">▶</span><span class="think-glyph">💭</span><span>Thought</span>' +
      '</div>' +
      '<div class="thinking-body show"><div class="inner">' + escapeHtml(body) + '</div></div>';
    messagesEl.appendChild(block);
  }
  scrollToBottom();
}

function toggleTool(header) {
  header.querySelector('.chev').classList.toggle('expanded');
  header.nextElementSibling.classList.toggle('show');
}

// ── 权限弹窗 ──
function addPermissionDialog(data) {
  hideEmptyState();
  const div = document.createElement('div');
  div.className = 'dialog-card';
  div.id = 'perm-' + data.id;
  div.innerHTML =
    '<div class="dialog-title">🔒 Permission required — ' + escapeHtml(data.toolName) + '</div>' +
    '<div class="dialog-desc">' + escapeHtml(data.description) + '</div>' +
    '<div class="dialog-actions">' +
      '<button class="btn-allow" onclick="respondPerm(\'' + data.id + '\', \'allow\')">Allow</button>' +
      '<button class="btn-always" onclick="respondPerm(\'' + data.id + '\', \'allowAlways\')">Allow Always</button>' +
      '<button class="btn-deny" onclick="respondPerm(\'' + data.id + '\', \'deny\')">Deny</button>' +
    '</div>';
  messagesEl.appendChild(div);
  scrollToBottom();
}

function respondPerm(id, response) {
  ws.send(JSON.stringify({ type: 'permission_response', data: { id, response } }));
  const el = document.getElementById('perm-' + id);
  if (el) {
    el.classList.add('answered');
    el.innerHTML = '<div style="color:var(--text-faint);font-size:12.5px;">🔒 Permission — ' + response + '</div>';
  }
}

// ── Ask User 弹窗 ──
function addAskUserDialog(data) {
  hideEmptyState();
  const div = document.createElement('div');
  div.className = 'dialog-card';
  div.id = 'ask-' + data.id;
  div.style.borderLeftColor = 'var(--accent-2)';

  let html = '<div class="dialog-title">❓ Question</div>';
  const questions = data.questions || [];
  questions.forEach((q, qi) => {
    html += '<div class="q-block">';
    html += '<div class="q-text">' + escapeHtml(q.question || q.Text || '') + '</div>';
    const options = q.options || q.Options || [];
    options.forEach((opt) => {
      const label = opt.label || opt.Label || '';
      const desc = opt.description || opt.Description || '';
      html += '<label class="q-option">' +
        '<input type="radio" name="ask_' + data.id + '_' + qi + '" value="' + escapeHtml(label) + '"> ' +
        '<span class="opt-label">' + escapeHtml(label) + '</span>' +
        (desc ? '<span class="opt-desc">— ' + escapeHtml(desc) + '</span>' : '') +
        '</label>';
    });
    html += '<label class="q-option">' +
      '<input type="radio" name="ask_' + data.id + '_' + qi + '" value="__other__"> ' +
      '<span class="opt-desc">Other:</span>' +
      '<input type="text" class="q-other-input" id="ask_other_' + data.id + '_' + qi + '">' +
      '</label>';
    html += '</div>';
  });
  html += '<div class="dialog-actions"><button class="btn-allow" onclick="respondAsk(\'' + data.id + '\',' + questions.length + ')">Submit</button></div>';

  div.innerHTML = html;
  messagesEl.appendChild(div);
  scrollToBottom();
}

function respondAsk(id, qCount) {
  const answers = {};
  for (let i = 0; i < qCount; i++) {
    const radios = document.querySelectorAll('input[name="ask_' + id + '_' + i + '"]');
    let val = '';
    radios.forEach(r => {
      if (r.checked) {
        val = r.value === '__other__' ? document.getElementById('ask_other_' + id + '_' + i).value : r.value;
      }
    });
    answers['question_' + i] = val;
  }
  ws.send(JSON.stringify({ type: 'ask_user_response', data: { id, answers } }));
  const el = document.getElementById('ask-' + id);
  if (el) {
    el.classList.add('answered');
    el.style.borderLeftColor = 'var(--border)';
    el.innerHTML = '<div style="color:var(--text-faint);font-size:12.5px;">✓ Answered</div>';
  }
}

// ── 滚动控制 ──
scrollWrap.addEventListener('scroll', () => {
  const { scrollTop, scrollHeight, clientHeight } = scrollWrap;
  autoScroll = scrollHeight - scrollTop - clientHeight < 60;
  scrollFab.style.display = autoScroll ? 'none' : 'flex';
});
scrollFab.addEventListener('click', () => {
  autoScroll = true;
  scrollWrap.scrollTop = scrollWrap.scrollHeight;
  scrollFab.style.display = 'none';
});

function scrollToBottom() {
  if (autoScroll) {
    requestAnimationFrame(() => { scrollWrap.scrollTop = scrollWrap.scrollHeight; });
  }
}

// ── 侧边栏：折叠/展开 ──
function setSidebarCollapsed(collapsed) {
  appEl.classList.toggle('sidebar-collapsed', collapsed);
  try { localStorage.setItem('wendream_sidebar_collapsed', collapsed ? '1' : '0'); } catch(e) {}
}

(function initSidebarState() {
  let collapsed = window.innerWidth <= 860;
  try {
    const saved = localStorage.getItem('wendream_sidebar_collapsed');
    if (saved !== null && window.innerWidth > 860) collapsed = saved === '1';
  } catch(e) {}
  setSidebarCollapsed(collapsed);
})();

sidebarToggleBtn.addEventListener('click', () => {
  setSidebarCollapsed(!appEl.classList.contains('sidebar-collapsed'));
});
sidebarBackdrop.addEventListener('click', () => setSidebarCollapsed(true));

// ── 侧边栏：会话列表 ──
const ICON_TRASH = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M4 7h16M9 7V4h6v3M6 7l1 13a2 2 0 002 2h6a2 2 0 002-2l1-13" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const ICON_PENCIL = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M12 20h9M16.5 3.5a2.12 2.12 0 013 3L7 19l-4 1 1-4L16.5 3.5z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';

newChatBtn.addEventListener('click', () => {
  if (streaming || !ws || ws.readyState !== WebSocket.OPEN) return;
  ws.send(JSON.stringify({ type: 'new_session', data: {} }));
  if (window.innerWidth <= 860) setSidebarCollapsed(true);
});

function groupSessionsByDate(list) {
  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const oneDay = 86400000;
  const buckets = { today: [], yesterday: [], week: [], month: [], older: [] };
  list.forEach(s => {
    const t = new Date(s.lastActive).getTime();
    if (t >= startOfToday) buckets.today.push(s);
    else if (t >= startOfToday - oneDay) buckets.yesterday.push(s);
    else if (t >= startOfToday - 7 * oneDay) buckets.week.push(s);
    else if (t >= startOfToday - 30 * oneDay) buckets.month.push(s);
    else buckets.older.push(s);
  });
  return [
    { label: '今天', items: buckets.today },
    { label: '昨天', items: buckets.yesterday },
    { label: '近 7 天', items: buckets.week },
    { label: '近 30 天', items: buckets.month },
    { label: '更早', items: buckets.older },
  ];
}

function renderSessionList() {
  if (!sessions.length) {
    sessionListEl.innerHTML = '<div class="session-empty-hint">暂无会话</div>';
    return;
  }
  const query = sessionSearchEl.value.trim().toLowerCase();
  const filtered = query
    ? sessions.filter(s => (s.title || '新对话').toLowerCase().includes(query))
    : sessions;
  if (!filtered.length) {
    sessionListEl.innerHTML = '<div class="session-empty-hint">没有匹配的会话</div>';
    return;
  }
  const groups = groupSessionsByDate(filtered);
  let html = '';
  groups.forEach(g => {
    if (!g.items.length) return;
    html += '<div class="sidebar-section-label">' + g.label + '</div>';
    g.items.forEach(s => {
      const title = escapeHtml(s.title || '新对话');
      const safeId = escapeAttr(s.id);
      const active = s.id === currentSessionId ? ' active' : '';
      html += '<div class="session-item' + active + '" data-id="' + safeId + '">' +
        '<span class="session-title">' + title + '</span>' +
        '<button class="session-rename" data-id="' + safeId + '" title="Rename">' + ICON_PENCIL + '</button>' +
        '<button class="session-delete" data-id="' + safeId + '" title="Delete">' + ICON_TRASH + '</button>' +
      '</div>';
    });
  });
  sessionListEl.innerHTML = html;

  sessionListEl.querySelectorAll('.session-item').forEach(el => {
    el.addEventListener('click', (e) => {
      if (e.target.closest('.session-delete') || e.target.closest('.session-rename')) return;
      const id = el.dataset.id;
      if (id === currentSessionId || streaming || !ws || ws.readyState !== WebSocket.OPEN) return;
      ws.send(JSON.stringify({ type: 'load_session', data: { id } }));
      if (window.innerWidth <= 860) setSidebarCollapsed(true);
    });
  });
  sessionListEl.querySelectorAll('.session-delete').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const id = btn.dataset.id;
      const ok = await showConfirm('Delete conversation?', 'This cannot be undone.', 'Delete');
      if (!ok) return;
      ws.send(JSON.stringify({ type: 'delete_session', data: { id } }));
    });
  });
  sessionListEl.querySelectorAll('.session-rename').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      startRenameSession(btn.closest('.session-item'), btn.dataset.id);
    });
  });
}

function startRenameSession(itemEl, id) {
  const titleEl = itemEl.querySelector('.session-title');
  const currentTitle = titleEl.textContent;
  const input = document.createElement('input');
  input.type = 'text';
  input.className = 'session-title-input';
  input.value = currentTitle;
  titleEl.replaceWith(input);
  input.focus();
  input.select();

  let done = false;
  const commit = () => {
    if (done) return;
    done = true;
    const newTitle = input.value.trim();
    if (newTitle && newTitle !== currentTitle) {
      ws.send(JSON.stringify({ type: 'rename_session', data: { id, title: newTitle } }));
    } else {
      renderSessionList();
    }
  };
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); input.blur(); }
    else if (e.key === 'Escape') { done = true; renderSessionList(); }
  });
  input.addEventListener('blur', commit);
}

sessionSearchEl.addEventListener('input', renderSessionList);

// ── 模型/provider 切换 ──
function renderProviderSelect(providers, active) {
  providerSelect.innerHTML = providers.map(p =>
    '<option value="' + p.name + '">' + p.name + ' (' + p.model + ')</option>'
  ).join('');
  if (active) providerSelect.value = active;
}
providerSelect.addEventListener('change', () => {
  if (streaming || !ws || ws.readyState !== WebSocket.OPEN) return;
  ws.send(JSON.stringify({ type: 'switch_provider', data: { name: providerSelect.value } }));
});

// ── 图片放大预览 ──
function openLightbox(src) {
  lightboxImg.src = src;
  imageLightbox.classList.add('show');
}
function closeLightbox() {
  imageLightbox.classList.remove('show');
  lightboxImg.src = '';
}
messagesEl.addEventListener('click', (e) => {
  const img = e.target.closest('.bubble-user-images img');
  if (img) openLightbox(img.src);
});
lightboxClose.addEventListener('click', closeLightbox);
imageLightbox.addEventListener('click', (e) => {
  if (e.target === imageLightbox) closeLightbox();
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && imageLightbox.classList.contains('show')) closeLightbox();
});

// ── 自定义确认弹窗（替代原生 confirm()） ──
let confirmResolve = null;
function showConfirm(title, desc, confirmLabel) {
  confirmTitleEl.textContent = title;
  confirmDescEl.textContent = desc;
  confirmOkBtn.textContent = confirmLabel || 'Confirm';
  confirmModal.classList.add('show');
  return new Promise((resolve) => { confirmResolve = resolve; });
}
function closeConfirm(result) {
  confirmModal.classList.remove('show');
  if (confirmResolve) { confirmResolve(result); confirmResolve = null; }
}
confirmOkBtn.addEventListener('click', () => closeConfirm(true));
confirmCancelBtn.addEventListener('click', () => closeConfirm(false));
confirmModal.addEventListener('click', (e) => {
  if (e.target === confirmModal) closeConfirm(false);
});
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && confirmModal.classList.contains('show')) closeConfirm(false);
});

// ── 图片/文件上传 ──
function makeFileChip(icon, name, onRemove) {
  const chip = document.createElement('div');
  chip.className = 'file-chip';
  const iconEl = document.createElement('span');
  iconEl.className = 'file-chip-icon';
  iconEl.textContent = icon;
  const nameEl = document.createElement('span');
  nameEl.className = 'file-chip-name';
  nameEl.textContent = name;
  chip.appendChild(iconEl);
  chip.appendChild(nameEl);
  if (onRemove) {
    const removeBtn = document.createElement('button');
    removeBtn.className = 'file-chip-remove';
    removeBtn.type = 'button';
    removeBtn.textContent = '×';
    removeBtn.addEventListener('click', onRemove);
    chip.appendChild(removeBtn);
  }
  return chip;
}

function renderAttachmentPreview() {
  imagePreviewRow.innerHTML = '';
  pendingImages.forEach((img, idx) => {
    const item = document.createElement('div');
    item.className = 'image-preview-item';
    const thumb = document.createElement('img');
    thumb.src = 'data:' + img.media_type + ';base64,' + img.data;
    const removeBtn = document.createElement('button');
    removeBtn.className = 'image-preview-remove';
    removeBtn.type = 'button';
    removeBtn.textContent = '×';
    removeBtn.addEventListener('click', () => {
      pendingImages.splice(idx, 1);
      renderAttachmentPreview();
    });
    item.appendChild(thumb);
    item.appendChild(removeBtn);
    imagePreviewRow.appendChild(item);
  });
  pendingDocuments.forEach((doc, idx) => {
    imagePreviewRow.appendChild(makeFileChip('📕', doc.name, () => {
      pendingDocuments.splice(idx, 1);
      renderAttachmentPreview();
    }));
  });
  pendingTextFiles.forEach((tf, idx) => {
    imagePreviewRow.appendChild(makeFileChip('📄', tf.name, () => {
      pendingTextFiles.splice(idx, 1);
      renderAttachmentPreview();
    }));
  });
  imagePreviewRow.classList.toggle('show', attachmentCount() > 0);
}

function handleFiles(files) {
  for (const file of files) {
    if (attachmentCount() >= MAX_ATTACHMENTS_PER_MESSAGE) {
      addSystem('最多同时上传 ' + MAX_ATTACHMENTS_PER_MESSAGE + ' 个文件/图片');
      break;
    }
    const kind = classifyFile(file);

    if (kind === 'image') {
      if (!visionEnabled) { addSystem('当前模型不支持识图，图片已忽略：' + file.name); continue; }
      if (file.size > MAX_IMAGE_BYTES) { addSystem('图片过大（超过 5MB）：' + file.name); continue; }
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result;
        const commaIdx = result.indexOf(',');
        const meta = result.substring(5, result.indexOf(';'));
        pendingImages.push({ media_type: meta, data: result.substring(commaIdx + 1) });
        renderAttachmentPreview();
      };
      reader.readAsDataURL(file);

    } else if (kind === 'pdf') {
      if (!visionEnabled) { addSystem('当前模型不支持解析 PDF，已忽略：' + file.name); continue; }
      if (file.size > MAX_DOCUMENT_BYTES) { addSystem('文件过大（超过 20MB）：' + file.name); continue; }
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result;
        const commaIdx = result.indexOf(',');
        const meta = result.substring(5, result.indexOf(';'));
        pendingDocuments.push({ media_type: meta, data: result.substring(commaIdx + 1), name: file.name });
        renderAttachmentPreview();
      };
      reader.readAsDataURL(file);

    } else if (kind === 'text') {
      if (file.size > MAX_TEXT_FILE_BYTES) { addSystem('文件过大（超过 300KB）：' + file.name); continue; }
      const reader = new FileReader();
      reader.onload = () => {
        pendingTextFiles.push({ name: file.name, content: reader.result });
        renderAttachmentPreview();
      };
      reader.readAsText(file);

    } else {
      addSystem('不支持的文件类型：' + (file.type || file.name));
    }
  }
}

uploadBtn.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', () => {
  handleFiles(fileInput.files);
  fileInput.value = '';
});
inputEl.addEventListener('paste', (e) => {
  if (!visionEnabled || !e.clipboardData) return;
  const items = Array.from(e.clipboardData.items).filter(i => i.type && i.type.startsWith('image/'));
  if (!items.length) return;
  e.preventDefault();
  handleFiles(items.map(i => i.getAsFile()).filter(Boolean));
});

// ── 拖拽上传 ──
let dragCounter = 0;
function isFileDrag(e) {
  return e.dataTransfer && Array.from(e.dataTransfer.types || []).includes('Files');
}
document.addEventListener('dragenter', (e) => {
  if (!isFileDrag(e)) return;
  e.preventDefault();
  dragCounter++;
  dropOverlay.classList.add('show');
});
document.addEventListener('dragover', (e) => {
  if (!isFileDrag(e)) return;
  e.preventDefault();
});
document.addEventListener('dragleave', (e) => {
  if (!isFileDrag(e)) return;
  dragCounter = Math.max(0, dragCounter - 1);
  if (dragCounter === 0) dropOverlay.classList.remove('show');
});
document.addEventListener('drop', (e) => {
  if (!isFileDrag(e)) return;
  e.preventDefault();
  dragCounter = 0;
  dropOverlay.classList.remove('show');
  if (e.dataTransfer.files && e.dataTransfer.files.length) {
    handleFiles(e.dataTransfer.files);
  }
});

// ── 输入处理 ──
function sendMessage() {
  if (slashMenu.classList.contains('show')) hideSlashMenu();
  const text = inputEl.value.trim();
  if ((!text && !attachmentCount()) || streaming) return;

  let wireText = text;
  pendingTextFiles.forEach(tf => { wireText += buildFileBlock(tf.name, tf.content); });

  addUser(wireText, pendingImages, pendingDocuments);
  ws.send(JSON.stringify({
    type: 'user_message',
    data: {
      content: wireText,
      images: pendingImages.map(p => ({ media_type: p.media_type, data: p.data })),
      documents: pendingDocuments.map(d => ({ media_type: d.media_type, data: d.data, name: d.name })),
    },
  }));
  inputEl.value = '';
  inputEl.style.height = 'auto';
  pendingImages = [];
  pendingDocuments = [];
  pendingTextFiles = [];
  renderAttachmentPreview();
  streaming = true;
  updateUI();
}

function cancelStreaming() {
  if (ws) ws.send(JSON.stringify({ type: 'cancel', data: {} }));
}

function updateUI() {
  if (streaming) {
    sendBtn.classList.add('stop-mode');
    sendBtn.innerHTML = ICON_STOP;
    sendBtn.disabled = false;
    sendBtn.title = 'Stop';
    inputEl.disabled = true;
  } else {
    sendBtn.classList.remove('stop-mode');
    sendBtn.innerHTML = ICON_SEND;
    sendBtn.disabled = false;
    sendBtn.title = 'Send';
    inputEl.disabled = false;
    inputEl.focus();
  }
}

sendBtn.addEventListener('click', () => {
  if (streaming) cancelStreaming(); else sendMessage();
});

// ── 斜杠命令菜单 ──
function showSlashMenu(filter) {
  const prefix = filter.toLowerCase();
  slashFiltered = allCommands.filter(c => c.name.startsWith(prefix));
  if (slashFiltered.length === 0) { hideSlashMenu(); return; }
  slashCursor = 0;
  renderSlashMenu();
  slashMenu.classList.add('show');
}

function hideSlashMenu() {
  slashMenu.classList.remove('show');
  slashFiltered = [];
  slashCursor = 0;
}

function renderSlashMenu() {
  slashMenu.innerHTML = slashFiltered.map((c, i) =>
    '<div class="slash-item' + (i === slashCursor ? ' active' : '') + '" data-idx="' + i + '">' +
      '<span class="cmd-name">/' + escapeHtml(c.name) + '</span>' +
      '<span class="cmd-desc">' + escapeHtml(c.description) + '</span>' +
    '</div>'
  ).join('');
  slashMenu.querySelectorAll('.slash-item').forEach(el => {
    el.addEventListener('mousedown', (e) => {
      e.preventDefault();
      selectSlashItem(parseInt(el.dataset.idx));
    });
  });
  const activeEl = slashMenu.querySelector('.active');
  if (activeEl) activeEl.scrollIntoView({ block: 'nearest' });
}

function selectSlashItem(idx) {
  const cmd = slashFiltered[idx];
  if (!cmd) return;
  inputEl.value = '/' + cmd.name + ' ';
  hideSlashMenu();
  inputEl.focus();
}

inputEl.addEventListener('keydown', (e) => {
  if (slashMenu.classList.contains('show')) {
    if (e.key === 'ArrowDown') { e.preventDefault(); slashCursor = Math.min(slashCursor + 1, slashFiltered.length - 1); renderSlashMenu(); return; }
    if (e.key === 'ArrowUp') { e.preventDefault(); slashCursor = Math.max(slashCursor - 1, 0); renderSlashMenu(); return; }
    if (e.key === 'Tab' || (e.key === 'Enter' && !e.shiftKey)) { e.preventDefault(); selectSlashItem(slashCursor); return; }
    if (e.key === 'Escape') { e.preventDefault(); hideSlashMenu(); return; }
  }
  if (e.key === 'Escape' && streaming) { e.preventDefault(); cancelStreaming(); return; }
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
});

inputEl.addEventListener('input', () => {
  inputEl.style.height = 'auto';
  inputEl.style.height = Math.min(inputEl.scrollHeight, 200) + 'px';

  const val = inputEl.value;
  if (val.startsWith('/') && !val.includes('\n')) {
    const prefix = val.substring(1).split(' ')[0];
    if (!val.includes(' ')) showSlashMenu(prefix); else hideSlashMenu();
  } else {
    hideSlashMenu();
  }
});

// ── 启动 ──
resetEmptyState();
connect();
inputEl.focus();
</script>
</body>
</html>"""
