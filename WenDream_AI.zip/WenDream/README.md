# WenDream · Extensible AI Agent Platform

**基于开源 MewCode Agent 深度二次开发的 Python AI Agent 工程项目。** 重点展示 Agent 工具调用效率、执行可靠性、跨平台工具运行和可复验的工程评测。

> **Origin / 上游归属**：WenDream is based on and deeply modified from **MewCode Agent**. 该项目并非从零开发全部 Agent 框架功能。许可与归属说明见 [`docs/ATTRIBUTION.md`](docs/ATTRIBUTION.md)。

## 项目简介

WenDream 提供终端 TUI 和浏览器 Web UI，通过 LLM 驱动的工具调用完成文件处理、代码检索与多步骤任务。它集成了多模型协议、MCP 工具扩展、Session/Memory、上下文压缩与子 Agent 协作能力；在此基础上，重点改造了 Agent 执行策略、工具工作区管理、Windows 兼容与权限处理，并建立真实 Agent Benchmark。

### 功能与架构

- **Agent：** 流式模型输出、工具调用、Completion Contract、Conversation-first、ToolSearch 按需暴露工具。
- **工具：** ReadFile、WriteFile、EditFile、Grep、Glob、Bash、MCP、Skill。
- **上下文：** 会话恢复、长工具结果落盘与历史压缩、项目记忆。
- **扩展：** Subagent / Coordinator / Worktree（底层基于 MewCode 能力）。
- **交互：** Textual TUI；Remote WebSocket + Web UI。
- **安全：** 权限规则、路径约束、Hook 拦截、Remote Token/Origin/XSS 检查；Linux/macOS 可选 OS 沙箱，**Windows 没有内核级沙箱**。

```mermaid
flowchart TD
  U[用户 · TUI / Web UI] --> A[WenDream Agent]
  A <--> L[LLM Provider]
  A --> T[Tool Registry / ToolSearch]
  T --> F[File / Grep / Glob / Bash]
  T --> M[MCP / Skills / Subagent]
  A <--> S[Session / Memory / Context]
  T --> P[Permission / Hooks]
  B[Benchmark + Trace] -. 验证 .-> A
```

## 工程优化成果

| 评测指标 | 早期阶段 | 冻结版本 / 专项优化后 | 说明 |
| --- | ---: | ---: | --- |
| 平均 Tool 调用/任务 | 6.07 | **2.50** | 多阶段整体改善，约 **-59%** |
| 平均 LLM 调用/任务 | 5.71 | **3.86** | 多阶段整体改善，约 **-32%** |
| 大型无匹配 Grep | 43.07s | **0.94s** | 合成 Fixture 专项测试，约 **-97.8%** |

以上数据来自不同工程迭代阶段，涵盖工具运行时修复与 Agent 策略调整，并非单独一个算法的严格 A/B 实验。技术分析见 [`docs/ENGINEERING_NOTES.md`](docs/ENGINEERING_NOTES.md)。

### 冻结版本（2026-10-20，v0.3.0）

30 个固定工程任务，7 类场景，每轮 2 个 SKIP，因此有 28 个可评分 Case；相同代码连续 3 轮：

| 轮次 | PASS | FAIL | TIMEOUT | SKIP | Task Success |
| --- | ---: | ---: | ---: | ---: | ---: |
| Run 1 | 27 | 1 | 0 | 2 | 96.4% |
| Run 2 | 28 | 0 | 0 | 2 | 100% |
| Run 3 | 28 | 0 | 0 | 2 | 100% |

**累计 83/84 次可评分执行通过、0 次超时。** 平均 Tool 调用三轮中位 **2.50/任务**，平均 LLM 调用 **3.86/任务**；仍存在 1 个跨轮不稳定 Case，不能宣称始终 100%。这些是小规模的自建工程评测，不是公开基准排行榜。详见 [`Benchmark`](benchmark/README.md) 与 [`Frozen Metrics`](benchmark/results/final_release_wendream/README.md)。

## 快速开始

**环境：** Python 3.11+、可访问的 LLM Provider API，推荐 `uv`。

```bash
# 在仓库根目录
python -m pip install -e .

# 创建私有配置目录
mkdir -p .wendream
cp config.example.yaml .wendream/config.yaml

# 在当前终端环境变量中设置 DEEPSEEK_API_KEY（不要写进仓库）
wendream --version
wendream
```

Windows PowerShell：

```powershell
py -m pip install -e .
New-Item -ItemType Directory -Force .wendream | Out-Null
Copy-Item config.example.yaml .wendream/config.yaml
$env:DEEPSEEK_API_KEY = Read-Host "Enter DEEPSEEK_API_KEY"
wendream
```

配置示例为 `config.example.yaml`，真实运行配置应存放在 `.wendream/config.yaml` 且被 Git 忽略。使用其他模型时调整 `providers` 的协议、模型名及密钥来源。

### CLI / Web

```bash
wendream                     # Textual TUI
wendream -p "解释这个项目的目录结构"   # 非交互模式：ASK 权限默认拒绝
wendream --remote            # 默认仅监听 127.0.0.1（本地浏览器）
```

> `--mode bypassPermissions` 将绕过人工确认，不建议在不可信工作目录使用。Remote 绑定到非本机地址时需要配置 Token；不要把服务直接暴露到公网。

## 测试与复现

```bash
python -m pytest tests -q
python scripts/audit_secrets.py

# 生成合成检索数据（仓库没有附带几千个自动生成文件）
python benchmark/tool_bench/make_fixtures.py
python benchmark/tool_bench/run_bench.py --label manual

# 需要模型 API、会产生调用费用：
python -m benchmark.runner_validated --case-id CTX_001 --results-dir local_check
```

部分测试依赖系统环境（Windows 编码、Unix 命令、Git 工作区、Node.js）；发布包的测试结果来自原环境，不表示跨平台全部测试已重新通过。

## 仓库结构

```text
wendream/                 Agent 产品源码
benchmark/               Benchmark Runner、用例与性能评测
  cases/                 验证版用例及历史用例
  fixtures/              少量可公开的固定任务数据
  tool_bench/             Grep/Glob 专项测试与生成器
  results/                冻结结果汇总（不含隐私 Trace）
tests/                   单元与回归测试
scripts/                 测试与迁移辅助脚本
docs/                    归属声明、工程优化笔记
config.example.yaml      无密钥配置示例
pyproject.toml / uv.lock  Python 依赖与可运行入口
```

## 限制与说明

- 不是通用 RAG、向量数据库或模型训练项目。
- PDF 输入受实际 LLM Provider 能力限制；Web 的部分会话编辑功能没有稳定库级 Benchmark 入口。
- 原始运行 Trace 含本机路径和会话内容，为隐私考虑不公开；只发布汇总证据。
- 平台隔离能力随操作系统变化，Windows **没有** bubblewrap / seatbelt 内核沙箱。
- **公开前**根据实际 MewCode 上游仓库授权要求补齐相应 LICENSE、NOTICE 和作者署名；参考 [`docs/ATTRIBUTION.md`](docs/ATTRIBUTION.md)。
